#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script simplificado para testar a IA treinável com dados de investimento.
Esta versão usa simulações e componentes leves para funcionar sem dependências pesadas.
"""

import os
import sys
import json
import logging
import argparse
from pathlib import Path
import random

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('tester_light')

# Adicionar diretório pai ao path para importar módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

class MockEmbedder:
    """Versão simulada do embedder para testes."""
    
    def __init__(self):
        self.embeddings = {}
        self.index = {}
        
    def generate_embedding(self, text):
        """Gera um embedding simulado."""
        # Criar um vetor aleatório como simulação
        import hashlib
        # Usar hash do texto para gerar um número determinístico
        hash_obj = hashlib.md5(text.encode())
        seed = int(hash_obj.hexdigest(), 16) % 10000
        random.seed(seed)
        # Gerar vetor de 10 dimensões
        return [random.random() for _ in range(10)]
    
    def process_document(self, doc_id, segments):
        """Processa um documento simulado."""
        self.embeddings[doc_id] = {}
        for i, segment in enumerate(segments):
            segment_id = f"{doc_id}_seg_{i}"
            self.embeddings[doc_id][segment_id] = self.generate_embedding(segment)
        
        return {
            "doc_id": doc_id,
            "model_name": "mock_model",
            "segment_count": len(segments),
            "embedding_dim": 10,
            "segments": list(self.embeddings[doc_id].keys())
        }
    
    def search_similar(self, query, top_k=5):
        """Busca segmentos similares (simulado)."""
        # Simulação simples de busca
        all_segments = []
        for doc_id, segments in self.embeddings.items():
            for segment_id, _ in segments.items():
                all_segments.append(segment_id)
        
        # Selecionar aleatoriamente alguns segmentos
        count = min(top_k, len(all_segments))
        if count == 0:
            return []
            
        selected = random.sample(all_segments, count)
        
        # Criar resultados simulados
        results = []
        for i, segment_id in enumerate(selected):
            results.append({
                "segment_id": segment_id,
                "similarity": 0.9 - (i * 0.1),  # Valores decrescentes
                "distance": i * 0.1
            })
        
        return results

class MockPipeline:
    """Pipeline simulado para testes."""
    
    def __init__(self):
        self.documents = {}
        self.embedder = MockEmbedder()
        
    def process_file(self, file_path, metadata=None):
        """Processa um arquivo (simulado)."""
        # Gerar ID para o documento
        import hashlib
        doc_id = hashlib.md5(file_path.encode()).hexdigest()[:12]
        
        # Ler conteúdo do arquivo
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except UnicodeDecodeError:
            # Tentar com latin-1 se utf-8 falhar
            with open(file_path, 'r', encoding='latin-1') as f:
                content = f.read()
        
        # Processar conteúdo
        segments = self._segment_text(content)
        
        # Extrair palavras-chave
        keywords = self._extract_keywords(content)
        
        # Armazenar documento
        self.documents[doc_id] = {
            "content": content,
            "segments": segments,
            "keywords": keywords,
            "metadata": metadata or {},
            "file_path": file_path
        }
        
        # Gerar embeddings simulados
        self.embedder.process_document(doc_id, segments)
        
        logger.info(f"Arquivo processado: {file_path} -> {doc_id}")
        return doc_id
    
    def _segment_text(self, text):
        """Segmenta o texto em partes menores."""
        # Dividir por parágrafos
        paragraphs = text.split('\n\n')
        
        # Filtrar parágrafos vazios
        paragraphs = [p.strip() for p in paragraphs if p.strip()]
        
        # Limitar a 50 segmentos para não sobrecarregar
        return paragraphs[:50]
    
    def _extract_keywords(self, text):
        """Extrai palavras-chave do texto."""
        # Lista de palavras-chave relacionadas a investimentos
        investment_terms = [
            "investimento", "ações", "bolsa", "mercado", "dinheiro", "finanças", 
            "renda", "juros", "dividendos", "economia", "poupança", "risco",
            "retorno", "lucro", "prejuízo", "volatilidade", "diversificação"
        ]
        
        # Encontrar termos no texto
        found_terms = []
        for term in investment_terms:
            if term.lower() in text.lower():
                found_terms.append(term)
        
        # Limitar a 10 termos
        return found_terms[:10]
    
    def search(self, query, top_k=5):
        """Busca informações relevantes para uma consulta."""
        # Buscar segmentos similares
        similar_segments = self.embedder.search_similar(query, top_k)
        
        # Enriquecer resultados
        results = []
        for item in similar_segments:
            segment_id = item["segment_id"]
            doc_id, seg_num = segment_id.split("_seg_")
            seg_num = int(seg_num)
            
            # Obter segmento
            if doc_id in self.documents:
                segments = self.documents[doc_id]["segments"]
                if seg_num < len(segments):
                    segment_text = segments[seg_num]
                    
                    # Adicionar ao resultado
                    results.append({
                        "segment_id": segment_id,
                        "doc_id": doc_id,
                        "similarity": item["similarity"],
                        "text": segment_text,
                        "metadata": self.documents[doc_id].get("metadata", {})
                    })
        
        return results
    
    def list_processed_documents(self):
        """Lista documentos processados."""
        docs = []
        for doc_id, doc in self.documents.items():
            metadata = doc.get("metadata", {})
            docs.append({
                "id": doc_id,
                "title": metadata.get("title", ""),
                "author": metadata.get("author", ""),
                "format": metadata.get("format", ""),
                "file_path": doc.get("file_path", ""),
                "segment_count": len(doc.get("segments", [])),
                "keywords": doc.get("keywords", [])
            })
        return docs

class MockAI:
    """Versão simulada da IA treinável para testes."""
    
    def __init__(self, pipeline):
        self.pipeline = pipeline
        self.training_history = []
    
    def import_and_process_file(self, file_path, metadata=None):
        """Importa e processa um arquivo."""
        try:
            doc_id = self.pipeline.process_file(file_path, metadata)
            
            # Obter informações do documento
            docs = self.pipeline.list_processed_documents()
            doc_info = next((doc for doc in docs if doc["id"] == doc_id), {})
            
            return {
                "status": "success",
                "doc_id": doc_id,
                "info": {
                    "processed_data": {
                        "keywords": doc_info.get("keywords", [])
                    }
                }
            }
        except Exception as e:
            logger.error(f"Erro ao importar arquivo: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def train_model(self, documents=None):
        """Treina o modelo (simulado)."""
        # Registrar treinamento
        import time
        training_record = {
            "timestamp": time.time(),
            "document_count": len(self.pipeline.documents)
        }
        self.training_history.append(training_record)
        
        return {
            "embedding_training": {
                "status": "success",
                "index_name": f"mock_index_{int(time.time())}",
                "document_count": len(self.pipeline.documents)
            },
            "fine_tuning": {
                "status": "skipped",
                "message": "Fine-tuning não disponível na versão de teste"
            }
        }
    
    def answer_question(self, question, top_k=5):
        """Responde a uma pergunta."""
        # Buscar informações relevantes
        results = self.pipeline.search(question, top_k)
        
        # Gerar resposta simulada
        if not results:
            response = "Não encontrei informações suficientes sobre esse assunto nos documentos importados."
        else:
            # Usar o primeiro resultado como base para a resposta
            base_text = results[0]["text"]
            
            # Adicionar citação
            response = f"{base_text}\n\nEsta informação foi encontrada nos documentos importados."
            
            # Adicionar menção a outros resultados se houver
            if len(results) > 1:
                response += f"\n\nExistem mais {len(results)-1} fontes relevantes para esta pergunta."
        
        # Formatar fontes
        sources = []
        for i, result in enumerate(results):
            metadata = result.get("metadata", {})
            source = {
                "reference_id": i + 1,
                "title": metadata.get("title", ""),
                "author": metadata.get("author", "")
            }
            sources.append(source)
        
        return {
            "query": question,
            "response": response,
            "sources": sources
        }
    
    def get_model_info(self):
        """Obtém informações sobre o modelo."""
        return {
            "models": {
                "embedding_model": "mock_model",
                "language_model": "mock_language_model",
                "current_index": "mock_index",
                "fine_tuning_enabled": False,
                "system_prompt": "Prompt de sistema simulado para testes"
            },
            "document_count": len(self.pipeline.documents),
            "training_history": self.training_history,
            "total_trainings": len(self.training_history)
        }

def create_sample_text_files(output_dir):
    """
    Cria arquivos de texto de amostra sobre investimentos.
    
    Args:
        output_dir: Diretório para salvar os arquivos
        
    Returns:
        Lista de caminhos para os arquivos criados
    """
    # Criar diretório se não existir
    os.makedirs(output_dir, exist_ok=True)
    
    # Conteúdo de amostra sobre investimentos
    samples = [
        {
            "filename": "investimentos_acoes.txt",
            "title": "Investimentos em Ações",
            "author": "Equipe IA Treinável",
            "category": "ações",
            "content": """# Investimentos em Ações: Guia Básico

## Introdução

Investir em ações significa tornar-se sócio de uma empresa de capital aberto, adquirindo uma pequena parte dela. Ao comprar ações, você passa a ser proprietário de uma fração da empresa e tem direito a participar dos seus resultados, sejam eles positivos ou negativos.

## Tipos de Ações

Existem dois tipos principais de ações:

1. **Ações Ordinárias (ON)**: Dão direito a voto nas assembleias de acionistas.
2. **Ações Preferenciais (PN)**: Geralmente não dão direito a voto, mas oferecem preferência na distribuição de dividendos.

## Retornos do Investimento em Ações

O retorno do investimento em ações pode vir de duas formas:

1. **Valorização**: Quando o preço da ação aumenta e você pode vender por um valor maior do que pagou.
2. **Dividendos**: Parte do lucro da empresa que é distribuída aos acionistas periodicamente.

## Estratégias de Investimento

### Buy and Hold (Comprar e Segurar)
Esta estratégia consiste em comprar ações de boas empresas e mantê-las por longos períodos, independentemente das flutuações de curto prazo do mercado. É baseada na ideia de que, no longo prazo, boas empresas tendem a valorizar e gerar retornos consistentes.

### Value Investing (Investimento em Valor)
Popularizada por Benjamin Graham e Warren Buffett, esta estratégia busca identificar ações que estejam sendo negociadas abaixo do seu valor intrínseco. O investidor procura empresas sólidas, com bons fundamentos, mas que estejam temporariamente subvalorizadas pelo mercado.

### Growth Investing (Investimento em Crescimento)
Foca em empresas com alto potencial de crescimento, mesmo que suas ações pareçam caras pelos métodos tradicionais de avaliação. Investidores buscam empresas inovadoras, em setores em expansão, que possam multiplicar seu valor no futuro."""
        },
        {
            "filename": "investimentos_renda_fixa.txt",
            "title": "Guia de Renda Fixa",
            "author": "Equipe IA Treinável",
            "category": "renda fixa",
            "content": """# Investimentos em Renda Fixa: Guia Completo

## O que é Renda Fixa?

Renda fixa é uma categoria de investimentos na qual o investidor empresta dinheiro a uma instituição (governo, banco ou empresa) e recebe em troca uma remuneração que pode ser previamente definida ou seguir um indexador. A principal característica da renda fixa é a previsibilidade dos retornos, em contraste com a renda variável.

## Principais Tipos de Investimentos em Renda Fixa

### Tesouro Direto
São títulos públicos emitidos pelo Governo Federal para financiar a dívida pública. Existem três categorias principais:

1. **Tesouro Prefixado**: Rentabilidade definida no momento da compra.
2. **Tesouro SELIC**: Rentabilidade atrelada à taxa SELIC.
3. **Tesouro IPCA+**: Rentabilidade atrelada à inflação (IPCA) mais uma taxa prefixada.

### CDB (Certificado de Depósito Bancário)
É um título emitido por bancos para captar recursos. O investidor empresta dinheiro ao banco e recebe juros por isso. A rentabilidade pode ser prefixada ou pós-fixada (geralmente atrelada ao CDI).

### LCI (Letra de Crédito Imobiliário) e LCA (Letra de Crédito do Agronegócio)
São títulos emitidos por instituições financeiras para financiar o setor imobiliário (LCI) ou o agronegócio (LCA). Oferecem isenção de Imposto de Renda para pessoas físicas e geralmente têm rentabilidade atrelada ao CDI."""
        },
        {
            "filename": "fundos_imobiliarios.txt",
            "title": "Fundos Imobiliários: Investimento em Imóveis sem Dor de Cabeça",
            "author": "Equipe IA Treinável",
            "category": "fundos imobiliários",
            "content": """# Fundos Imobiliários: Investimento em Imóveis sem Dor de Cabeça

## O que são Fundos Imobiliários (FIIs)?

Fundos Imobiliários (FIIs) são instrumentos de investimento que permitem aplicar em empreendimentos imobiliários sem a necessidade de comprar diretamente um imóvel. Funcionam como um condomínio de investidores, onde o dinheiro captado é utilizado para adquirir ou construir imóveis, que posteriormente geram renda através de aluguéis ou valorização.

## Como Funcionam os FIIs

Os FIIs são divididos em cotas, que representam uma fração do patrimônio do fundo. Ao comprar cotas, o investidor se torna proprietário de uma parcela de todos os imóveis do fundo e tem direito a receber proporcionalmente os rendimentos gerados.

A gestão dos imóveis é realizada por uma administradora profissional, que cuida de todos os aspectos operacionais: manutenção, busca por inquilinos, cobrança de aluguéis, etc. Isso elimina as dores de cabeça típicas de quem possui imóveis físicos.

## Tipos de Fundos Imobiliários

### Fundos de Tijolo
Investem diretamente em imóveis físicos, como escritórios, galpões logísticos, shopping centers ou hospitais. A renda vem principalmente dos aluguéis pagos pelos inquilinos.

### Fundos de Papel
Investem em títulos relacionados ao mercado imobiliário, como Certificados de Recebíveis Imobiliários (CRIs), Letras de Crédito Imobiliário (LCIs) e outros. A renda vem dos juros desses papéis."""
        }
    ]
    
    created_files = []
    
    for sample in samples:
        output_path = os.path.join(output_dir, sample["filename"])
        
        # Verificar se o arquivo já existe
        if os.path.exists(output_path):
            logger.info(f"Arquivo já existe: {output_path}")
        else:
            # Criar arquivo
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(sample["content"])
            logger.info(f"Arquivo criado: {output_path}")
        
        created_files.append({
            "path": output_path,
            "metadata": {
                "title": sample.get("title", ""),
                "author": sample.get("author", ""),
                "category": sample.get("category", "")
            }
        })
    
    return created_files

def test_import_and_train(ai, files):
    """
    Testa a importação de arquivos e treinamento do modelo.
    
    Args:
        ai: Instância da IA treinável
        files: Lista de arquivos a serem importados
    
    Returns:
        Resultado do treinamento
    """
    logger.info("Iniciando teste de importação e treinamento...")
    
    # Importar arquivos
    imported_docs = []
    
    for file_info in files:
        file_path = file_info["path"]
        metadata = file_info["metadata"]
        
        logger.info(f"Importando arquivo: {file_path}")
        result = ai.import_and_process_file(file_path, metadata)
        
        if result['status'] == 'success':
            logger.info(f"Arquivo importado com sucesso. ID do documento: {result['doc_id']}")
            imported_docs.append(result['doc_id'])
        else:
            logger.error(f"Erro ao importar arquivo: {result.get('message', 'Erro desconhecido')}")
    
    if not imported_docs:
        logger.error("Nenhum documento importado com sucesso. Abortando treinamento.")
        return None
    
    # Treinar modelo
    logger.info(f"Treinando modelo com {len(imported_docs)} documentos...")
    result = ai.train_model(imported_docs)
    
    # Verificar resultado do treinamento
    embedding_result = result.get('embedding_training', {})
    if embedding_result.get('status') == 'success':
        logger.info(f"Treinamento de embeddings concluído com sucesso.")
        logger.info(f"Índice criado: {embedding_result.get('index_name')}")
        logger.info(f"Documentos processados: {embedding_result.get('document_count')}")
    else:
        logger.error(f"Erro no treinamento de embeddings: {embedding_result.get('message', 'Erro desconhecido')}")
    
    return result

def test_questions(ai):
    """
    Testa o modelo com perguntas sobre investimentos.
    
    Args:
        ai: Instância da IA treinável
    
    Returns:
        Resultados das perguntas
    """
    logger.info("Testando modelo com perguntas sobre investimentos...")
    
    # Lista de perguntas para teste
    questions = [
        "Quais são as principais estratégias de investimento em ações?",
        "Como funcionam os fundos imobiliários e quais suas vantagens?",
        "Qual a diferença entre investimentos em renda fixa e renda variável?",
        "O que é a estratégia Buy and Hold e como aplicá-la?"
    ]
    
    results = []
    
    for question in questions:
        logger.info(f"Pergunta: {question}")
        
        try:
            # Fazer pergunta
            response_data = ai.answer_question(question)
            
            # Registrar resultado
            results.append({
                "question": question,
                "response": response_data['response'],
                "sources_count": len(response_data.get('sources', []))
            })
            
            logger.info(f"Resposta gerada com {len(response_data.get('sources', []))} fontes")
        except Exception as e:
            logger.error(f"Erro ao processar pergunta: {e}")
            results.append({
                "question": question,
                "error": str(e)
            })
    
    return results

def main():
    """Função principal para testar a IA treinável."""
    parser = argparse.ArgumentParser(description='Testar IA Treinável com dados de investimento (versão leve)')
    parser.add_argument('--data-dir', type=str, default='./test_data', help='Diretório para dados de teste')
    parser.add_argument('--output', type=str, default='./test_results.json', help='Arquivo para salvar resultados')
    
    args = parser.parse_args()
    
    # Criar diretório de dados se não existir
    os.makedirs(args.data_dir, exist_ok=True)
    
    # Inicializar pipeline e IA simulados
    pipeline = MockPipeline()
    ai = MockAI(pipeline)
    
    # Criar arquivos de texto de amostra
    files = create_sample_text_files(args.data_dir)
    
    # Importar e treinar
    training_result = test_import_and_train(ai, files)
    
    # Testar com perguntas
    question_results = test_questions(ai)
    
    # Salvar resultados
    results = {
        "files_processed": len(files),
        "questions_tested": len(question_results),
        "question_results": question_results,
        "model_info": ai.get_model_info()
    }
    
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    logger.info(f"Resultados salvos em {args.output}")
    
    # Mostrar resumo
    print("\n===== RESUMO DO TESTE =====")
    print(f"Arquivos processados: {len(files)}")
    print(f"Perguntas testadas: {len(question_results)}")
    print("\nExemplos de perguntas e respostas:")
    
    for i, result in enumerate(question_results[:3]):  # Mostrar apenas as 3 primeiras
        print(f"\nPergunta {i+1}: {result['question']}")
        if 'response' in result:
            # Limitar tamanho da resposta para exibição
            response = result['response']
            if len(response) > 300:
                response = response[:300] + "..."
            print(f"Resposta: {response}")
        else:
            print(f"Erro: {result.get('error', 'Desconhecido')}")
    
    print(f"\nResultados completos salvos em {args.output}")

if __name__ == "__main__":
    main()
