# Guia do Usuário - IA Treinável para Livros de Investimento

Este guia fornece instruções detalhadas sobre como utilizar a IA treinável para extrair conhecimento de seus livros e materiais sobre investimentos e riqueza.

## Índice

1. [Primeiros Passos](#primeiros-passos)
2. [Importação de Documentos](#importação-de-documentos)
3. [Treinamento do Modelo](#treinamento-do-modelo)
4. [Fazendo Perguntas](#fazendo-perguntas)
5. [Interface Web](#interface-web)
6. [Dicas e Boas Práticas](#dicas-e-boas-práticas)
7. [Solução de Problemas](#solução-de-problemas)

## Primeiros Passos

### Instalação

Antes de começar, certifique-se de que todas as dependências estão instaladas:

```bash
# Instalar dependências
pip install -r requirements.txt

# Baixar recursos do NLTK necessários
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords')"
```

### Verificação Inicial

Para verificar se o sistema está funcionando corretamente:

```bash
# Testar o sistema com dados de amostra
python test_system_light.py
```

Isso criará alguns arquivos de amostra sobre investimentos, importará para o sistema, treinará o modelo e testará com algumas perguntas básicas.

## Importação de Documentos

A primeira etapa para usar a IA treinável é importar seus documentos sobre investimentos e riqueza.

### Formatos Suportados

- **PDF** (.pdf): Livros, relatórios, artigos
- **Word** (.docx): Documentos do Microsoft Word
- **Texto** (.txt): Arquivos de texto simples

### Usando a Interface de Linha de Comando

```bash
# Importar um único arquivo
python cli.py import --file "/caminho/para/arquivo.pdf" --title "Título do Documento" --author "Nome do Autor" --category "Categoria"

# Importar todos os arquivos de um diretório
python cli.py import-dir --dir "/caminho/para/diretorio" --category "Categoria Padrão"
```

### Metadados Importantes

Ao importar documentos, forneça o máximo de metadados possível:

- **Título**: Nome do livro ou documento
- **Autor**: Autor ou fonte do conteúdo
- **Categoria**: Tipo de conteúdo (ex: "investimentos", "ações", "imóveis")
- **Ano**: Ano de publicação (opcional)
- **Descrição**: Breve descrição do conteúdo (opcional)

Estes metadados ajudam o sistema a organizar as informações e fornecer respostas mais contextualizadas.

## Treinamento do Modelo

Após importar documentos, você precisa treinar o modelo para que ele possa responder perguntas baseadas no conteúdo.

```bash
# Treinar o modelo com todos os documentos importados
python cli.py train

# Treinar apenas com documentos específicos (por ID)
python cli.py train --docs doc_id1 doc_id2 doc_id3

# Treinar apenas com documentos de uma categoria específica
python cli.py train --category "ações"
```

### Quando Treinar Novamente

Você deve treinar o modelo novamente quando:

- Importar novos documentos
- Excluir documentos existentes
- Modificar configurações importantes do sistema

O treinamento cria índices de busca que permitem recuperar informações relevantes rapidamente quando você faz perguntas.

## Fazendo Perguntas

Depois que o modelo estiver treinado, você pode fazer perguntas sobre o conteúdo dos documentos importados.

```bash
# Fazer uma pergunta simples
python cli.py ask "O que é diversificação de investimentos?"

# Fazer uma pergunta com contexto específico
python cli.py ask "Quais são as estratégias de Warren Buffett para investir em ações?"

# Salvar a resposta em um arquivo
python cli.py ask "Como funciona o mercado de ações?" --output "resposta.txt"
```

### Tipos de Perguntas Eficazes

- **Perguntas diretas**: "O que é um fundo imobiliário?"
- **Perguntas comparativas**: "Qual a diferença entre ações e títulos públicos?"
- **Perguntas sobre estratégias**: "Como montar uma carteira de investimentos diversificada?"
- **Perguntas sobre conceitos**: "O que significa liquidez no contexto de investimentos?"

### Limitações

O sistema só pode responder com base no conteúdo dos documentos que você importou. Se a informação não estiver presente nos documentos, o sistema informará que não encontrou dados suficientes.

## Interface Web

A interface web oferece uma experiência mais amigável para interagir com o sistema.

### Iniciando a Interface Web

```bash
# Iniciar o servidor web
python web_app.py
```

Acesse http://localhost:5000 no seu navegador.

### Recursos da Interface Web

- **Página Inicial**: Visão geral do sistema e estatísticas
- **Importar**: Interface para upload de documentos
- **Perguntas**: Área para fazer perguntas e ver respostas
- **Documentos**: Lista de todos os documentos importados
- **Treinamento**: Opções para treinar o modelo
- **Configurações**: Ajustes do sistema

## Dicas e Boas Práticas

### Organização de Documentos

- Importe documentos relacionados a temas específicos em lotes
- Use categorias consistentes para facilitar a organização
- Priorize documentos de alta qualidade e fontes confiáveis

### Formulação de Perguntas

- Seja específico em suas perguntas
- Inclua termos-chave relevantes
- Faça uma pergunta por vez
- Para tópicos complexos, divida em perguntas menores

### Otimização de Desempenho

- Evite importar o mesmo documento múltiplas vezes
- Remova documentos irrelevantes ou desatualizados
- Periodicamente verifique e otimize o sistema com `python cli.py optimize`

## Solução de Problemas

### Problemas Comuns

**Problema**: Respostas imprecisas ou irrelevantes
- **Solução**: Verifique se os documentos importados contêm as informações necessárias
- **Solução**: Reformule a pergunta com termos mais específicos
- **Solução**: Treine novamente o modelo após importar documentos mais relevantes

**Problema**: Erro ao importar documentos
- **Solução**: Verifique se o formato do arquivo é suportado
- **Solução**: Para PDFs complexos, tente converter para texto primeiro
- **Solução**: Verifique se há espaço suficiente em disco

**Problema**: Treinamento lento
- **Solução**: Reduza o número de documentos ou use um computador mais potente
- **Solução**: Configure um modelo de embeddings mais leve nas configurações

### Logs e Diagnóstico

Para problemas técnicos, verifique os logs do sistema:

```bash
# Ver logs recentes
python cli.py logs --lines 50

# Executar diagnóstico do sistema
python cli.py diagnose
```

## Próximos Passos

À medida que você se familiariza com o sistema, considere:

1. Expandir sua base de conhecimento com mais documentos
2. Experimentar diferentes configurações para otimizar resultados
3. Criar coleções temáticas de documentos para diferentes áreas de investimento
4. Exportar e compartilhar suas bases de conhecimento com outros usuários

---

Para suporte adicional ou dúvidas, consulte a documentação completa ou entre em contato com o desenvolvedor.
