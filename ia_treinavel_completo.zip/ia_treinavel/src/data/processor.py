#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo de processamento de texto para a IA treinável.
Responsável por limpar, tokenizar e processar textos importados.
"""

import os
import re
import json
import logging
import string
from typing import Dict, List, Optional, Tuple, Any, Union
from pathlib import Path
import pickle

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('processor')

class TextProcessor:
    """Classe para processamento de textos."""
    
    def __init__(self, processed_data_dir: str):
        """
        Inicializa o processador de texto.
        
        Args:
            processed_data_dir: Diretório para armazenar os dados processados
        """
        self.processed_data_dir = Path(processed_data_dir)
        self.processed_data_dir.mkdir(parents=True, exist_ok=True)
        
        # Carregar recursos de NLP conforme necessário
        self._load_nlp_resources()
    
    def _load_nlp_resources(self):
        """Carrega recursos necessários para processamento de texto."""
        try:
            import nltk
            # Verificar e baixar recursos do NLTK se necessário
            nltk_resources = ['punkt', 'stopwords', 'wordnet']
            for resource in nltk_resources:
                try:
                    nltk.data.find(f'tokenizers/{resource}')
                except LookupError:
                    logger.info(f"Baixando recurso NLTK: {resource}")
                    nltk.download(resource, quiet=True)
            
            # Carregar stopwords
            from nltk.corpus import stopwords
            self.stopwords = set(stopwords.words('portuguese') + stopwords.words('english'))
            
            logger.info("Recursos de NLP carregados com sucesso")
        except ImportError:
            logger.warning("NLTK não está instalado. Algumas funcionalidades podem não estar disponíveis.")
            self.stopwords = set()
    
    def clean_text(self, text: str) -> str:
        """
        Limpa o texto removendo caracteres especiais, espaços extras, etc.
        
        Args:
            text: Texto a ser limpo
            
        Returns:
            Texto limpo
        """
        if not text:
            return ""
        
        # Remover caracteres de controle e substituir quebras de linha por espaços
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\xff]', '', text)
        text = re.sub(r'\n+', ' ', text)
        
        # Remover espaços extras
        text = re.sub(r'\s+', ' ', text)
        
        # Remover URLs
        text = re.sub(r'https?://\S+|www\.\S+', '', text)
        
        # Remover emails
        text = re.sub(r'\S+@\S+', '', text)
        
        return text.strip()
    
    def tokenize_text(self, text: str) -> List[str]:
        """
        Tokeniza o texto em sentenças.
        
        Args:
            text: Texto a ser tokenizado
            
        Returns:
            Lista de sentenças
        """
        try:
            import nltk
            return nltk.sent_tokenize(text)
        except ImportError:
            logger.warning("NLTK não está instalado. Usando tokenização básica.")
            # Tokenização básica por pontuação
            sentences = re.split(r'(?<=[.!?])\s+', text)
            return [s.strip() for s in sentences if s.strip()]
    
    def remove_stopwords(self, text: str) -> str:
        """
        Remove stopwords do texto.
        
        Args:
            text: Texto para remover stopwords
            
        Returns:
            Texto sem stopwords
        """
        if not self.stopwords:
            return text
        
        words = text.split()
        filtered_words = [word for word in words if word.lower() not in self.stopwords]
        return ' '.join(filtered_words)
    
    def extract_keywords(self, text: str, top_n: int = 10) -> List[str]:
        """
        Extrai palavras-chave do texto.
        
        Args:
            text: Texto para extrair palavras-chave
            top_n: Número de palavras-chave a retornar
            
        Returns:
            Lista de palavras-chave
        """
        try:
            import nltk
            from nltk.probability import FreqDist
            
            # Tokenizar palavras
            words = nltk.word_tokenize(text.lower())
            
            # Remover pontuação e stopwords
            words = [word for word in words 
                    if word not in string.punctuation 
                    and word not in self.stopwords
                    and len(word) > 2]
            
            # Calcular frequência
            fdist = FreqDist(words)
            
            # Retornar as top_n palavras mais frequentes
            return [word for word, _ in fdist.most_common(top_n)]
        except ImportError:
            logger.warning("NLTK não está instalado. Usando extração básica de palavras-chave.")
            # Método básico
            words = re.findall(r'\b\w{3,}\b', text.lower())
            word_counts = {}
            for word in words:
                if word not in self.stopwords:
                    word_counts[word] = word_counts.get(word, 0) + 1
            
            # Ordenar por contagem
            sorted_words = sorted(word_counts.items(), key=lambda x: x[1], reverse=True)
            return [word for word, _ in sorted_words[:top_n]]
    
    def extract_entities(self, text: str) -> Dict[str, List[str]]:
        """
        Extrai entidades nomeadas do texto.
        
        Args:
            text: Texto para extrair entidades
            
        Returns:
            Dicionário com tipos de entidades e listas de entidades
        """
        try:
            import spacy
            
            # Carregar modelo do spaCy (baixar se necessário)
            try:
                nlp = spacy.load("pt_core_news_sm")
            except OSError:
                logger.info("Baixando modelo do spaCy para português...")
                os.system("python -m spacy download pt_core_news_sm")
                nlp = spacy.load("pt_core_news_sm")
            
            # Processar texto
            doc = nlp(text)
            
            # Extrair entidades
            entities = {}
            for ent in doc.ents:
                if ent.label_ not in entities:
                    entities[ent.label_] = []
                if ent.text not in entities[ent.label_]:
                    entities[ent.label_].append(ent.text)
            
            return entities
        except ImportError:
            logger.warning("spaCy não está instalado. Extração de entidades não disponível.")
            return {}
    
    def segment_document(self, text: str, max_segment_length: int = 1000) -> List[str]:
        """
        Segmenta um documento em partes menores para processamento.
        
        Args:
            text: Texto completo do documento
            max_segment_length: Tamanho máximo de cada segmento em caracteres
            
        Returns:
            Lista de segmentos de texto
        """
        # Tokenizar em sentenças
        sentences = self.tokenize_text(text)
        
        segments = []
        current_segment = ""
        
        for sentence in sentences:
            # Se adicionar esta sentença exceder o tamanho máximo, iniciar novo segmento
            if len(current_segment) + len(sentence) > max_segment_length and current_segment:
                segments.append(current_segment.strip())
                current_segment = sentence
            else:
                current_segment += " " + sentence
        
        # Adicionar o último segmento se não estiver vazio
        if current_segment.strip():
            segments.append(current_segment.strip())
        
        return segments
    
    def process_document(self, doc_id: str, text: str, metadata: Dict = None) -> Dict:
        """
        Processa um documento completo.
        
        Args:
            doc_id: ID do documento
            text: Texto do documento
            metadata: Metadados do documento (opcional)
            
        Returns:
            Dicionário com resultados do processamento
        """
        # Criar diretório para o documento processado
        doc_dir = self.processed_data_dir / doc_id
        doc_dir.mkdir(exist_ok=True)
        
        # Limpar texto
        clean_text = self.clean_text(text)
        
        # Segmentar documento
        segments = self.segment_document(clean_text)
        
        # Extrair palavras-chave
        keywords = self.extract_keywords(clean_text)
        
        # Extrair entidades (se disponível)
        entities = self.extract_entities(clean_text)
        
        # Salvar resultados
        processed_data = {
            "doc_id": doc_id,
            "segments": segments,
            "segment_count": len(segments),
            "keywords": keywords,
            "entities": entities,
            "char_count": len(clean_text),
            "word_count": len(clean_text.split()),
        }
        
        # Adicionar metadados se fornecidos
        if metadata:
            processed_data["metadata"] = metadata
        
        # Salvar texto limpo
        clean_text_file = doc_dir / "clean_text.txt"
        with open(clean_text_file, 'w', encoding='utf-8') as f:
            f.write(clean_text)
        
        # Salvar segmentos
        segments_file = doc_dir / "segments.json"
        with open(segments_file, 'w', encoding='utf-8') as f:
            json.dump(segments, f, ensure_ascii=False, indent=2)
        
        # Salvar dados processados
        processed_file = doc_dir / "processed_data.json"
        with open(processed_file, 'w', encoding='utf-8') as f:
            # Converter para formato serializável
            serializable_data = processed_data.copy()
            serializable_data["entities"] = dict(serializable_data["entities"])
            json.dump(serializable_data, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Documento {doc_id} processado com sucesso: {len(segments)} segmentos")
        return processed_data
    
    def get_processed_document(self, doc_id: str) -> Dict:
        """
        Obtém os dados processados de um documento.
        
        Args:
            doc_id: ID do documento
            
        Returns:
            Dicionário com dados processados
        """
        processed_file = self.processed_data_dir / doc_id / "processed_data.json"
        if not processed_file.exists():
            raise FileNotFoundError(f"Dados processados não encontrados para o documento {doc_id}")
        
        with open(processed_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def get_document_segments(self, doc_id: str) -> List[str]:
        """
        Obtém os segmentos de um documento processado.
        
        Args:
            doc_id: ID do documento
            
        Returns:
            Lista de segmentos de texto
        """
        segments_file = self.processed_data_dir / doc_id / "segments.json"
        if not segments_file.exists():
            raise FileNotFoundError(f"Segmentos não encontrados para o documento {doc_id}")
        
        with open(segments_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def get_clean_text(self, doc_id: str) -> str:
        """
        Obtém o texto limpo de um documento processado.
        
        Args:
            doc_id: ID do documento
            
        Returns:
            Texto limpo
        """
        clean_text_file = self.processed_data_dir / doc_id / "clean_text.txt"
        if not clean_text_file.exists():
            raise FileNotFoundError(f"Texto limpo não encontrado para o documento {doc_id}")
        
        with open(clean_text_file, 'r', encoding='utf-8') as f:
            return f.read()


# Função de conveniência para criar um processador com configuração padrão
def create_processor(base_dir: str = None) -> TextProcessor:
    """
    Cria um processador de texto com configuração padrão.
    
    Args:
        base_dir: Diretório base para armazenar dados (opcional)
        
    Returns:
        Instância de TextProcessor
    """
    if not base_dir:
        base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data')
    
    processed_data_dir = os.path.join(base_dir, 'processed')
    
    return TextProcessor(processed_data_dir)


# Exemplo de uso
if __name__ == "__main__":
    # Criar processador
    processor = create_processor()
    
    # Processar um texto de exemplo
    text = """
    Investir em ações é uma forma de se tornar sócio de empresas e participar dos seus lucros.
    Existem diferentes estratégias de investimento, como buy and hold, trading e análise fundamentalista.
    Warren Buffett é considerado um dos maiores investidores de todos os tempos, com uma fortuna estimada em bilhões de dólares.
    """
    
    # Processar documento
    result = processor.process_document("exemplo_doc", text)
    
    # Mostrar resultados
    print(f"Palavras-chave: {result['keywords']}")
    print(f"Número de segmentos: {result['segment_count']}")
    if result['entities']:
        print(f"Entidades encontradas: {result['entities']}")
