#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Interface web para a IA treinável.
Permite importar dados, treinar o modelo e fazer consultas através de uma interface gráfica.
"""

import os
import sys
import json
import logging
from typing import Dict, List, Optional, Any
from pathlib import Path
import tempfile
from flask import Flask, request, render_template, jsonify, redirect, url_for, flash, send_from_directory

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('web_app')

# Adicionar diretório pai ao path para importar módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Importar módulos do projeto
from src.data.pipeline import create_pipeline
from src.models.model import create_trainable_ai

# Criar aplicação Flask
app = Flask(__name__, 
            template_folder=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates'),
            static_folder=os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static'))

# Configurar diretório de upload
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50 MB

# Configurar chave secreta para sessões
app.secret_key = os.urandom(24)

# Variáveis globais para armazenar instâncias
pipeline = None
ai = None

def initialize_ai():
    """Inicializa o pipeline de dados e a IA treinável."""
    global pipeline, ai
    
    if pipeline is None:
        pipeline = create_pipeline()
    
    if ai is None:
        ai = create_trainable_ai(pipeline)
    
    return ai

@app.route('/')
def index():
    """Rota para a página inicial."""
    initialize_ai()
    return render_template('index.html')

@app.route('/ask', methods=['GET', 'POST'])
def ask():
    """Rota para fazer perguntas ao modelo."""
    initialize_ai()
    
    if request.method == 'POST':
        question = request.form.get('question', '')
        include_context = request.form.get('include_context') == 'on'
        top_k = int(request.form.get('top_k', 5))
        
        if not question:
            flash('Por favor, digite uma pergunta.', 'error')
            return redirect(url_for('ask'))
        
        try:
            # Fazer pergunta com ou sem contexto
            if include_context:
                response_data = ai.answer_with_context(question, top_k)
            else:
                response_data = ai.answer_question(question, top_k)
            
            return render_template('ask.html', 
                                  question=question, 
                                  response=response_data['response'], 
                                  sources=response_data.get('sources', []),
                                  include_context=include_context,
                                  top_k=top_k)
        except Exception as e:
            logger.error(f"Erro ao processar pergunta: {e}")
            flash(f'Erro ao processar pergunta: {str(e)}', 'error')
            return redirect(url_for('ask'))
    
    return render_template('ask.html')

@app.route('/import', methods=['GET', 'POST'])
def import_data():
    """Rota para importar dados para o sistema."""
    initialize_ai()
    
    if request.method == 'POST':
        # Verificar se foi enviado um arquivo
        if 'file' not in request.files:
            flash('Nenhum arquivo selecionado.', 'error')
            return redirect(request.url)
        
        file = request.files['file']
        
        # Verificar se o arquivo tem nome
        if file.filename == '':
            flash('Nenhum arquivo selecionado.', 'error')
            return redirect(request.url)
        
        # Obter metadados
        title = request.form.get('title', '')
        author = request.form.get('author', '')
        category = request.form.get('category', '')
        
        metadata = {}
        if title:
            metadata['title'] = title
        if author:
            metadata['author'] = author
        if category:
            metadata['category'] = category
        
        try:
            # Salvar arquivo temporariamente
            temp_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(temp_path)
            
            # Importar e processar arquivo
            result = ai.import_and_process_file(temp_path, metadata)
            
            if result['status'] == 'success':
                flash(f'Arquivo importado com sucesso. ID do documento: {result["doc_id"]}', 'success')
                
                # Mostrar palavras-chave se disponíveis
                keywords = result['info'].get('processed_data', {}).get('keywords', [])
                if keywords:
                    flash(f'Palavras-chave: {", ".join(keywords)}', 'info')
            else:
                flash(f'Erro ao importar arquivo: {result.get("message", "Erro desconhecido")}', 'error')
            
            return redirect(url_for('import_data'))
        except Exception as e:
            logger.error(f"Erro ao importar arquivo: {e}")
            flash(f'Erro ao importar arquivo: {str(e)}', 'error')
            return redirect(url_for('import_data'))
    
    return render_template('import.html')

@app.route('/train', methods=['GET', 'POST'])
def train():
    """Rota para treinar o modelo."""
    initialize_ai()
    
    if request.method == 'POST':
        try:
            # Treinar modelo
            result = ai.train_model()
            
            # Verificar resultado do treinamento de embeddings
            embedding_result = result.get('embedding_training', {})
            if embedding_result.get('status') == 'success':
                flash('Treinamento de embeddings concluído com sucesso.', 'success')
                flash(f'Índice criado: {embedding_result.get("index_name")}', 'info')
                flash(f'Documentos processados: {embedding_result.get("document_count")}', 'info')
            else:
                flash(f'Erro no treinamento de embeddings: {embedding_result.get("message", "Erro desconhecido")}', 'error')
            
            # Verificar resultado do fine-tuning
            fine_tuning_result = result.get('fine_tuning', {})
            if fine_tuning_result.get('status') == 'submitted':
                flash(f'Job de fine-tuning iniciado: {fine_tuning_result.get("job_id")}', 'success')
                flash(f'Exemplos de treinamento: {fine_tuning_result.get("example_count")}', 'info')
            elif fine_tuning_result.get('status') == 'skipped':
                flash('Fine-tuning não executado (desabilitado nas configurações).', 'info')
            else:
                flash(f'Erro no fine-tuning: {fine_tuning_result.get("message", "Erro desconhecido")}', 'error')
            
            return redirect(url_for('train'))
        except Exception as e:
            logger.error(f"Erro ao treinar modelo: {e}")
            flash(f'Erro ao treinar modelo: {str(e)}', 'error')
            return redirect(url_for('train'))
    
    # Obter informações do modelo para exibição
    model_info = ai.get_model_info()
    
    return render_template('train.html', model_info=model_info)

@app.route('/documents')
def documents():
    """Rota para listar documentos importados."""
    initialize_ai()
    
    try:
        # Listar documentos
        documents = pipeline.list_processed_documents()
        return render_template('documents.html', documents=documents)
    except Exception as e:
        logger.error(f"Erro ao listar documentos: {e}")
        flash(f'Erro ao listar documentos: {str(e)}', 'error')
        return redirect(url_for('index'))

@app.route('/config', methods=['GET', 'POST'])
def config():
    """Rota para configurar o sistema."""
    initialize_ai()
    
    if request.method == 'POST':
        # Atualizar prompt de sistema
        new_prompt = request.form.get('system_prompt', '')
        
        if new_prompt:
            try:
                result = ai.update_system_prompt(new_prompt)
                
                if result['status'] == 'success':
                    flash('Prompt de sistema atualizado com sucesso.', 'success')
                else:
                    flash(f'Erro ao atualizar prompt: {result.get("message", "Erro desconhecido")}', 'error')
            except Exception as e:
                logger.error(f"Erro ao atualizar prompt: {e}")
                flash(f'Erro ao atualizar prompt: {str(e)}', 'error')
        
        return redirect(url_for('config'))
    
    # Obter informações do modelo para exibição
    model_info = ai.get_model_info()
    
    return render_template('config.html', model_info=model_info)

@app.route('/api/ask', methods=['POST'])
def api_ask():
    """API para fazer perguntas ao modelo."""
    initialize_ai()
    
    data = request.json
    
    if not data or 'question' not in data:
        return jsonify({'error': 'Pergunta não fornecida'}), 400
    
    question = data['question']
    include_context = data.get('include_context', False)
    top_k = data.get('top_k', 5)
    
    try:
        # Fazer pergunta com ou sem contexto
        if include_context:
            response_data = ai.answer_with_context(question, top_k)
        else:
            response_data = ai.answer_question(question, top_k)
        
        return jsonify(response_data)
    except Exception as e:
        logger.error(f"Erro ao processar pergunta via API: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/import', methods=['POST'])
def api_import():
    """API para importar dados para o sistema."""
    initialize_ai()
    
    # Verificar se foi enviado um arquivo
    if 'file' not in request.files:
        return jsonify({'error': 'Nenhum arquivo enviado'}), 400
    
    file = request.files['file']
    
    # Verificar se o arquivo tem nome
    if file.filename == '':
        return jsonify({'error': 'Nome de arquivo vazio'}), 400
    
    # Obter metadados
    metadata = {}
    form_data = request.form.to_dict()
    
    if 'title' in form_data and form_data['title']:
        metadata['title'] = form_data['title']
    if 'author' in form_data and form_data['author']:
        metadata['author'] = form_data['author']
    if 'category' in form_data and form_data['category']:
        metadata['category'] = form_data['category']
    
    try:
        # Salvar arquivo temporariamente
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(temp_path)
        
        # Importar e processar arquivo
        result = ai.import_and_process_file(temp_path, metadata)
        
        return jsonify(result)
    except Exception as e:
        logger.error(f"Erro ao importar arquivo via API: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/train', methods=['POST'])
def api_train():
    """API para treinar o modelo."""
    initialize_ai()
    
    try:
        # Treinar modelo
        result = ai.train_model()
        return jsonify(result)
    except Exception as e:
        logger.error(f"Erro ao treinar modelo via API: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/documents', methods=['GET'])
def api_documents():
    """API para listar documentos importados."""
    initialize_ai()
    
    try:
        # Listar documentos
        documents = pipeline.list_processed_documents()
        return jsonify({'documents': documents})
    except Exception as e:
        logger.error(f"Erro ao listar documentos via API: {e}")
        return jsonify({'error': str(e)}), 500

def create_app():
    """Cria e configura a aplicação Flask."""
    # Criar diretórios de templates e static se não existirem
    templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
    
    os.makedirs(templates_dir, exist_ok=True)
    os.makedirs(static_dir, exist_ok=True)
    
    # Criar templates básicos
    create_templates()
    
    # Criar arquivos estáticos básicos
    create_static_files()
    
    return app

def create_templates():
    """Cria os templates HTML básicos."""
    templates_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'templates')
    
    # Template base
    base_html = """<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}IA Treinável para Investimentos{% endblock %}</title>
    <link rel="stylesheet" href="{{ url_for('static', filename='css/style.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>IA Treinável para Investimentos</h1>
            <nav>
                <ul>
                    <li><a href="{{ url_for('index') }}">Início</a></li>
                    <li><a href="{{ url_for('ask') }}">Perguntar</a></li>
                    <li><a href="{{ url_for('import_data') }}">Importar</a></li>
                    <li><a href="{{ url_for('train') }}">Treinar</a></li>
                    <li><a href="{{ url_for('documents') }}">Documentos</a></li>
                    <li><a href="{{ url_for('config') }}">Configurações</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <main class="container">
        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                <div class="flash-messages">
                    {% for category, message in messages %}
                        <div class="flash-message {{ category }}">
                            {{ message }}
                        </div>
                    {% endfor %}
                </div>
            {% endif %}
        {% endwith %}
        
        {% block content %}{% endblock %}
    </main>
    
    <footer>
        <div class="container">
            <p>&copy; 2025 IA Treinável para Investimentos</p>
        </div>
    </footer>
    
    <script src="{{ url_for('static', filename='js/script.js') }}"></script>
</body>
</html>
"""
    
    # Template da página inicial
    index_html = """{% extends "base.html" %}

{% block title %}Início - IA Treinável para Investimentos{% endblock %}

{% block content %}
    <section class="hero">
        <h2>Bem-vindo à IA Treinável para Investimentos</h2>
        <p>Um sistema de inteligência artificial que você pode treinar com seus próprios dados sobre livros de investimento e riqueza.</p>
        
        <div class="features">
            <div class="feature">
                <i class="fas fa-upload"></i>
                <h3>Importe seus dados</h3>
                <p>Adicione livros, artigos e documentos sobre investimentos para criar sua base de conhecimento personalizada.</p>
                <a href="{{ url_for('import_data') }}" class="btn">Importar dados</a>
            </div>
            
            <div class="feature">
                <i class="fas fa-brain"></i>
                <h3>Treine o modelo</h3>
                <p>Treine a IA com os dados importados para que ela aprenda e se adapte ao seu conhecimento específico.</p>
                <a href="{{ url_for('train') }}" class="btn">Treinar modelo</a>
            </div>
            
            <div class="feature">
                <i class="fas fa-question-circle"></i>
                <h3>Faça perguntas</h3>
                <p>Consulte a IA sobre investimentos, finanças pessoais e estratégias para construir riqueza.</p>
                <a href="{{ url_for('ask') }}" class="btn">Perguntar</a>
            </div>
        </div>
    </section>
    
    <section class="how-it-works">
        <h2>Como funciona</h2>
        
        <div class="steps">
            <div class="step">
                <div class="step-number">1</div>
                <h3>Importação de dados</h3>
                <p>Faça upload de livros e documentos sobre investimentos em formatos como PDF, DOCX e TXT.</p>
            </div>
            
            <div class="step">
                <div class="step-number">2</div>
                <h3>Processamento</h3>
                <p>O sistema processa automaticamente os textos, extraindo informações relevantes e criando representações vetoriais.</p>
            </div>
            
            <div class="step">
                <div class="step-number">3</div>
                <h3>Treinamento</h3>
                <p>A IA é treinada com os dados processados, aprendendo a recuperar e gerar informações precisas.</p>
            </div>
            
            <div class="step">
                <div class="step-number">4</div>
                <h3>Consulta</h3>
                <p>Faça perguntas em linguagem natural e receba respostas baseadas no conhecimento dos seus próprios livros.</p>
            </div>
        </div>
    </section>
{% endblock %}
"""
    
    # Template da página de perguntas
    ask_html = """{% extends "base.html" %}

{% block title %}Perguntar - IA Treinável para Investimentos{% endblock %}

{% block content %}
    <section class="ask-section">
        <h2>Faça uma pergunta</h2>
        
        <form method="post" action="{{ url_for('ask') }}" class="ask-form">
            <div class="form-group">
                <label for="question">Sua pergunta:</label>
                <textarea id="question" name="question" rows="3" required>{{ question or '' }}</textarea>
            </div>
            
            <div class="form-options">
                <div class="form-check">
                    <input type="checkbox" id="include_context" name="include_context" {% if include_context %}checked{% endif %}>
                    <label for="include_context">Incluir contexto adicional</label>
                </div>
                
                <div class="form-group inline">
                    <label for="top_k">Número de resultados:</label>
                    <select id="top_k" name="top_k">
                        <option value="3" {% if top_k == 3 %}selected{% endif %}>3</option>
                        <option value="5" {% if not top_k or top_k == 5 %}selected{% endif %}>5</option>
                        <option value="10" {% if top_k == 10 %}selected{% endif %}>10</option>
                    </select>
                </div>
            </div>
            
            <button type="submit" class="btn">Perguntar</button>
        </form>
        
        {% if response %}
            <div class="response-section">
                <h3>Resposta:</h3>
                <div class="response-content">
                    {{ response|safe }}
                </div>
                
                {% if sources %}
                    <div class="sources">
                        <h4>Fontes:</h4>
                        <ul>
                            {% for source in sources %}
                                <li>
                                    {% if source.title %}
                                        <strong>"{{ source.title }}"</strong>
                                        {% if source.author %}
                                            por {{ source.author }}
                                        {% endif %}
                                    {% elif source.path %}
                                        {{ source.path.split('/')[-1] }}
                                    {% else %}
                                        Fonte {{ loop.index }}
                                    {% endif %}
                                </li>
                            {% endfor %}
                        </ul>
                    </div>
                {% endif %}
            </div>
        {% endif %}
    </section>
{% endblock %}
"""
    
    # Template da página de importação
    import_html = """{% extends "base.html" %}

{% block title %}Importar - IA Treinável para Investimentos{% endblock %}

{% block content %}
    <section class="import-section">
        <h2>Importar dados</h2>
        
        <form method="post" action="{{ url_for('import_data') }}" enctype="multipart/form-data" class="import-form">
            <div class="form-group">
                <label for="file">Selecione um arquivo:</label>
                <input type="file" id="file" name="file" required>
                <small>Formatos suportados: PDF, DOCX, TXT (máx. 50MB)</small>
            </div>
            
            <div class="form-group">
                <label for="title">Título (opcional):</label>
                <input type="text" id="title" name="title">
            </div>
            
            <div class="form-group">
                <label for="author">Autor (opcional):</label>
                <input type="text" id="author" name="author">
            </div>
            
            <div class="form-group">
                <label for="category">Categoria (opcional):</label>
                <input type="text" id="category" name="category">
                <small>Ex: investimentos, finanças pessoais, imóveis, ações</small>
            </div>
            
            <button type="submit" class="btn">Importar</button>
        </form>
        
        <div class="import-info">
            <h3>Sobre a importação de dados</h3>
            <p>Ao importar um documento, o sistema irá:</p>
            <ul>
                <li>Extrair o texto do documento</li>
                <li>Processar e limpar o conteúdo</li>
                <li>Segmentar em partes menores para melhor recuperação</li>
                <li>Extrair palavras-chave e entidades</li>
                <li>Gerar representações vetoriais para busca semântica</li>
            </ul>
            <p>Após importar documentos, não se esqueça de <a href="{{ url_for('train') }}">treinar o modelo</a> para que as novas informações sejam incorporadas.</p>
        </div>
    </section>
{% endblock %}
"""
    
    # Template da página de treinamento
    train_html = """{% extends "base.html" %}

{% block title %}Treinar - IA Treinável para Investimentos{% endblock %}

{% block content %}
    <section class="train-section">
        <h2>Treinar modelo</h2>
        
        <div class="model-info">
            <h3>Informações do modelo atual</h3>
            
            <div class="info-grid">
                <div class="info-item">
                    <strong>Modelo de embeddings:</strong>
                    <span>{{ model_info.models.embedding_model }}</span>
                </div>
                
                <div class="info-item">
                    <strong>Modelo de linguagem:</strong>
                    <span>{{ model_info.models.language_model }}</span>
                </div>
                
                <div class="info-item">
                    <strong>Índice atual:</strong>
                    <span>{{ model_info.models.current_index or 'Nenhum' }}</span>
                </div>
                
                <div class="info-item">
                    <strong>Documentos processados:</strong>
                    <span>{{ model_info.document_count }}</span>
                </div>
                
                <div class="info-item">
                    <strong>Total de treinamentos:</strong>
                    <span>{{ model_info.total_trainings }}</span>
                </div>
                
                <div class="info-item">
                    <strong>Fine-tuning habilitado:</strong>
                    <span>{{ 'Sim' if model_info.models.fine_tuning_enabled else 'Não' }}</span>
                </div>
            </div>
            
            {% if model_info.training_history %}
                <h4>Últimos treinamentos</h4>
                <div class="training-history">
                    {% for training in model_info.training_history %}
                        <div class="training-item">
                            <div class="training-type {{ training.type }}">{{ training.type }}</div>
                            <div class="training-details">
                                <div class="training-date">{{ training.timestamp|int|datetime }}</div>
                                
                                {% if training.type == 'embedding' %}
                                    <div>Índice: {{ training.index_name }}</div>
                                    <div>Documentos: {{ training.documents|length }}</div>
                                {% elif training.type == 'fine_tuning' %}
                                    <div>Status: {{ training.status }}</div>
                                    <div>Job ID: {{ training.job_id }}</div>
                                    {% if training.fine_tuned_model %}
                                        <div>Modelo: {{ training.fine_tuned_model }}</div>
                                    {% endif %}
                                {% endif %}
                            </div>
                        </div>
                    {% endfor %}
                </div>
            {% endif %}
        </div>
        
        <form method="post" action="{{ url_for('train') }}" class="train-form">
            <p>Clique no botão abaixo para treinar o modelo com todos os documentos importados.</p>
            <button type="submit" class="btn">Iniciar treinamento</button>
        </form>
        
        <div class="train-info">
            <h3>Sobre o treinamento</h3>
            <p>O treinamento do modelo consiste em duas etapas principais:</p>
            <ol>
                <li>
                    <strong>Treinamento de embeddings:</strong> Cria representações vetoriais dos documentos e constrói um índice para busca eficiente.
                </li>
                <li>
                    <strong>Fine-tuning (opcional):</strong> Ajusta o modelo de linguagem para melhorar a qualidade das respostas com base nos seus dados.
                </li>
            </ol>
            <p>O treinamento é necessário após importar novos documentos para que o sistema possa incorporar as novas informações.</p>
        </div>
    </section>
{% endblock %}
"""
    
    # Template da página de documentos
    documents_html = """{% extends "base.html" %}

{% block title %}Documentos - IA Treinável para Investimentos{% endblock %}

{% block content %}
    <section class="documents-section">
        <h2>Documentos importados</h2>
        
        {% if documents %}
            <div class="documents-list">
                {% for doc in documents %}
                    <div class="document-item">
                        <div class="document-header">
                            <h3>{{ doc.title or 'Documento sem título' }}</h3>
                            <span class="document-id">ID: {{ doc.id }}</span>
                        </div>
                        
                        <div class="document-details">
                            {% if doc.author %}
                                <div class="detail-item">
                                    <strong>Autor:</strong> {{ doc.author }}
                                </div>
                            {% endif %}
                            
                            {% if doc.format %}
                                <div class="detail-item">
                                    <strong>Formato:</strong> {{ doc.format }}
                                </div>
                            {% endif %}
                            
                            {% if doc.category %}
                                <div class="detail-item">
                                    <strong>Categoria:</strong> {{ doc.category }}
                                </div>
                            {% endif %}
                            
                            {% if doc.segment_count %}
                                <div class="detail-item">
                                    <strong>Segmentos:</strong> {{ doc.segment_count }}
                                </div>
                            {% endif %}
                        </div>
                        
                        {% if doc.keywords %}
                            <div class="document-keywords">
                                <strong>Palavras-chave:</strong>
                                <div class="keywords-list">
                                    {% for keyword in doc.keywords %}
                                        <span class="keyword">{{ keyword }}</span>
                                    {% endfor %}
                                </div>
                            </div>
                        {% endif %}
                    </div>
                {% endfor %}
            </div>
        {% else %}
            <div class="no-documents">
                <p>Nenhum documento importado ainda.</p>
                <a href="{{ url_for('import_data') }}" class="btn">Importar documentos</a>
            </div>
        {% endif %}
    </section>
{% endblock %}
"""
    
    # Template da página de configurações
    config_html = """{% extends "base.html" %}

{% block title %}Configurações - IA Treinável para Investimentos{% endblock %}

{% block content %}
    <section class="config-section">
        <h2>Configurações do sistema</h2>
        
        <form method="post" action="{{ url_for('config') }}" class="config-form">
            <div class="form-group">
                <label for="system_prompt">Prompt de sistema:</label>
                <textarea id="system_prompt" name="system_prompt" rows="10">{{ model_info.models.system_prompt }}</textarea>
                <small>Este prompt define o comportamento e as diretrizes da IA ao gerar respostas.</small>
            </div>
            
            <button type="submit" class="btn">Salvar configurações</button>
        </form>
        
        <div class="config-info">
            <h3>Informações do modelo</h3>
            
            <div class="info-grid">
                <div class="info-item">
                    <strong>Modelo de embeddings:</strong>
                    <span>{{ model_info.models.embedding_model }}</span>
                </div>
                
                <div class="info-item">
                    <strong>Modelo de linguagem:</strong>
                    <span>{{ model_info.models.language_model }}</span>
                </div>
                
                <div class="info-item">
                    <strong>Fine-tuning habilitado:</strong>
                    <span>{{ 'Sim' if model_info.models.fine_tuning_enabled else 'Não' }}</span>
                </div>
            </div>
        </div>
    </section>
{% endblock %}
"""
    
    # Criar arquivos de template
    with open(os.path.join(templates_dir, 'base.html'), 'w') as f:
        f.write(base_html)
    
    with open(os.path.join(templates_dir, 'index.html'), 'w') as f:
        f.write(index_html)
    
    with open(os.path.join(templates_dir, 'ask.html'), 'w') as f:
        f.write(ask_html)
    
    with open(os.path.join(templates_dir, 'import.html'), 'w') as f:
        f.write(import_html)
    
    with open(os.path.join(templates_dir, 'train.html'), 'w') as f:
        f.write(train_html)
    
    with open(os.path.join(templates_dir, 'documents.html'), 'w') as f:
        f.write(documents_html)
    
    with open(os.path.join(templates_dir, 'config.html'), 'w') as f:
        f.write(config_html)

def create_static_files():
    """Cria os arquivos estáticos básicos (CSS e JS)."""
    static_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static')
    css_dir = os.path.join(static_dir, 'css')
    js_dir = os.path.join(static_dir, 'js')
    
    os.makedirs(css_dir, exist_ok=True)
    os.makedirs(js_dir, exist_ok=True)
    
    # CSS básico
    css = """/* Estilos gerais */
:root {
    --primary-color: #2c3e50;
    --secondary-color: #3498db;
    --accent-color: #e74c3c;
    --light-color: #ecf0f1;
    --dark-color: #2c3e50;
    --success-color: #2ecc71;
    --warning-color: #f39c12;
    --error-color: #e74c3c;
    --info-color: #3498db;
    --border-radius: 4px;
    --box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    line-height: 1.6;
    color: var(--dark-color);
    background-color: #f5f7fa;
}

.container {
    width: 100%;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

a {
    color: var(--secondary-color);
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

h1, h2, h3, h4 {
    margin-bottom: 1rem;
    color: var(--primary-color);
}

ul {
    list-style: none;
}

/* Botões */
.btn {
    display: inline-block;
    background-color: var(--secondary-color);
    color: white;
    padding: 0.5rem 1rem;
    border: none;
    border-radius: var(--border-radius);
    cursor: pointer;
    font-size: 1rem;
    text-align: center;
    transition: background-color 0.3s;
}

.btn:hover {
    background-color: #2980b9;
    text-decoration: none;
}

/* Header */
header {
    background-color: var(--primary-color);
    color: white;
    padding: 1rem 0;
    box-shadow: var(--box-shadow);
}

header .container {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header h1 {
    color: white;
    margin: 0;
    font-size: 1.5rem;
}

header nav ul {
    display: flex;
}

header nav ul li {
    margin-left: 1.5rem;
}

header nav ul li a {
    color: white;
    font-weight: 500;
}

header nav ul li a:hover {
    color: var(--light-color);
}

/* Main content */
main {
    padding: 2rem 0;
    min-height: calc(100vh - 140px);
}

/* Footer */
footer {
    background-color: var(--primary-color);
    color: white;
    padding: 1rem 0;
    text-align: center;
}

/* Flash messages */
.flash-messages {
    margin-bottom: 1.5rem;
}

.flash-message {
    padding: 0.75rem 1rem;
    margin-bottom: 0.5rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
}

.flash-message.success {
    background-color: #d4edda;
    color: #155724;
    border: 1px solid #c3e6cb;
}

.flash-message.error {
    background-color: #f8d7da;
    color: #721c24;
    border: 1px solid #f5c6cb;
}

.flash-message.info {
    background-color: #d1ecf1;
    color: #0c5460;
    border: 1px solid #bee5eb;
}

.flash-message.warning {
    background-color: #fff3cd;
    color: #856404;
    border: 1px solid #ffeeba;
}

/* Forms */
.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
}

.form-group input[type="text"],
.form-group input[type="file"],
.form-group textarea,
.form-group select {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #ddd;
    border-radius: var(--border-radius);
    font-size: 1rem;
}

.form-group textarea {
    resize: vertical;
}

.form-group small {
    display: block;
    margin-top: 0.25rem;
    color: #6c757d;
}

.form-check {
    display: flex;
    align-items: center;
    margin-bottom: 0.5rem;
}

.form-check input[type="checkbox"] {
    margin-right: 0.5rem;
}

.form-options {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.form-group.inline {
    display: flex;
    align-items: center;
    margin-bottom: 0;
}

.form-group.inline label {
    margin-right: 0.5rem;
    margin-bottom: 0;
}

.form-group.inline select {
    width: auto;
}

/* Home page */
.hero {
    text-align: center;
    margin-bottom: 3rem;
}

.hero h2 {
    font-size: 2rem;
    margin-bottom: 1rem;
}

.hero p {
    font-size: 1.2rem;
    margin-bottom: 2rem;
    color: #555;
}

.features {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 2rem;
    margin-top: 2rem;
}

.feature {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    text-align: center;
}

.feature i {
    font-size: 2.5rem;
    color: var(--secondary-color);
    margin-bottom: 1rem;
}

.feature h3 {
    margin-bottom: 1rem;
}

.feature p {
    margin-bottom: 1.5rem;
    color: #555;
}

.how-it-works {
    margin-top: 3rem;
}

.how-it-works h2 {
    text-align: center;
    margin-bottom: 2rem;
}

.steps {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
}

.step {
    background-color: white;
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    position: relative;
}

.step-number {
    position: absolute;
    top: -15px;
    left: -15px;
    width: 40px;
    height: 40px;
    background-color: var(--secondary-color);
    color: white;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    font-weight: bold;
    font-size: 1.2rem;
}

/* Ask page */
.ask-section {
    max-width: 800px;
    margin: 0 auto;
}

.ask-form {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    margin-bottom: 2rem;
}

.response-section {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    margin-top: 2rem;
}

.response-content {
    background-color: #f8f9fa;
    padding: 1.5rem;
    border-radius: var(--border-radius);
    margin-bottom: 1.5rem;
    white-space: pre-line;
}

.sources {
    border-top: 1px solid #ddd;
    padding-top: 1rem;
}

.sources ul {
    list-style: disc;
    padding-left: 1.5rem;
}

.sources li {
    margin-bottom: 0.5rem;
}

/* Import page */
.import-section {
    max-width: 800px;
    margin: 0 auto;
}

.import-form {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    margin-bottom: 2rem;
}

.import-info {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
}

.import-info ul {
    list-style: disc;
    padding-left: 1.5rem;
    margin-bottom: 1rem;
}

.import-info li {
    margin-bottom: 0.5rem;
}

/* Train page */
.train-section {
    max-width: 800px;
    margin: 0 auto;
}

.model-info {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    margin-bottom: 2rem;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1rem;
    margin-bottom: 1.5rem;
}

.info-item {
    margin-bottom: 0.5rem;
}

.info-item strong {
    display: block;
    margin-bottom: 0.25rem;
    color: #555;
}

.training-history {
    margin-top: 1rem;
}

.training-item {
    display: flex;
    margin-bottom: 1rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid #eee;
}

.training-type {
    padding: 0.25rem 0.5rem;
    border-radius: var(--border-radius);
    font-size: 0.8rem;
    font-weight: bold;
    text-transform: uppercase;
    margin-right: 1rem;
    min-width: 100px;
    text-align: center;
}

.training-type.embedding {
    background-color: #d1ecf1;
    color: #0c5460;
}

.training-type.fine_tuning {
    background-color: #d4edda;
    color: #155724;
}

.training-details {
    flex: 1;
}

.training-date {
    color: #6c757d;
    margin-bottom: 0.25rem;
    font-size: 0.9rem;
}

.train-form {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    margin-bottom: 2rem;
    text-align: center;
}

.train-info {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
}

.train-info ol {
    padding-left: 1.5rem;
    margin-bottom: 1rem;
}

.train-info li {
    margin-bottom: 0.5rem;
}

/* Documents page */
.documents-section {
    max-width: 800px;
    margin: 0 auto;
}

.documents-list {
    display: grid;
    grid-template-columns: 1fr;
    gap: 1.5rem;
}

.document-item {
    background-color: white;
    padding: 1.5rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
}

.document-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
    padding-bottom: 0.5rem;
    border-bottom: 1px solid #eee;
}

.document-header h3 {
    margin: 0;
}

.document-id {
    font-size: 0.8rem;
    color: #6c757d;
}

.document-details {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 0.5rem;
    margin-bottom: 1rem;
}

.detail-item {
    margin-bottom: 0.5rem;
}

.document-keywords {
    margin-top: 1rem;
    padding-top: 0.5rem;
    border-top: 1px solid #eee;
}

.keywords-list {
    display: flex;
    flex-wrap: wrap;
    margin-top: 0.5rem;
}

.keyword {
    background-color: #e9ecef;
    padding: 0.25rem 0.5rem;
    border-radius: 20px;
    font-size: 0.8rem;
    margin-right: 0.5rem;
    margin-bottom: 0.5rem;
}

.no-documents {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    text-align: center;
}

.no-documents p {
    margin-bottom: 1rem;
    color: #6c757d;
}

/* Config page */
.config-section {
    max-width: 800px;
    margin: 0 auto;
}

.config-form {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
    margin-bottom: 2rem;
}

.config-info {
    background-color: white;
    padding: 2rem;
    border-radius: var(--border-radius);
    box-shadow: var(--box-shadow);
}

/* Responsive */
@media (max-width: 768px) {
    header .container {
        flex-direction: column;
    }
    
    header h1 {
        margin-bottom: 1rem;
    }
    
    header nav ul {
        flex-wrap: wrap;
        justify-content: center;
    }
    
    header nav ul li {
        margin: 0 0.5rem 0.5rem;
    }
    
    .features, .steps {
        grid-template-columns: 1fr;
    }
    
    .form-options {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .form-group.inline {
        margin-top: 1rem;
    }
}
"""
    
    # JavaScript básico
    js = """// Função para formatar data e hora
function formatDateTime(timestamp) {
    const date = new Date(timestamp * 1000);
    return date.toLocaleString();
}

// Adicionar formatador de data para templates
if (typeof Jinja2 !== 'undefined') {
    Jinja2.filters.datetime = function(timestamp) {
        return formatDateTime(timestamp);
    };
}

// Remover mensagens flash após alguns segundos
document.addEventListener('DOMContentLoaded', function() {
    const flashMessages = document.querySelectorAll('.flash-message');
    
    flashMessages.forEach(function(message) {
        setTimeout(function() {
            message.style.opacity = '0';
            setTimeout(function() {
                message.style.display = 'none';
            }, 500);
        }, 5000);
    });
});

// Melhorar experiência do formulário de upload
document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('file');
    
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            const fileName = this.files[0]?.name;
            if (fileName) {
                const titleInput = document.getElementById('title');
                if (titleInput && !titleInput.value) {
                    // Extrair nome do arquivo sem extensão como título sugerido
                    const suggestedTitle = fileName.split('.').slice(0, -1).join('.');
                    titleInput.value = suggestedTitle;
                }
            }
        });
    }
});

// Melhorar experiência do formulário de perguntas
document.addEventListener('DOMContentLoaded', function() {
    const questionForm = document.querySelector('.ask-form');
    const submitButton = questionForm?.querySelector('button[type="submit"]');
    
    if (questionForm && submitButton) {
        questionForm.addEventListener('submit', function() {
            submitButton.disabled = true;
            submitButton.innerHTML = 'Processando...';
        });
    }
});
"""
    
    # Criar arquivos estáticos
    with open(os.path.join(css_dir, 'style.css'), 'w') as f:
        f.write(css)
    
    with open(os.path.join(js_dir, 'script.js'), 'w') as f:
        f.write(js)

# Criar filtro para formatação de data
@app.template_filter('datetime')
def format_datetime(timestamp):
    """Formata timestamp para data e hora legíveis."""
    from datetime import datetime
    return datetime.fromtimestamp(timestamp).strftime('%d/%m/%Y %H:%M:%S')

if __name__ == '__main__':
    # Criar aplicação
    app = create_app()
    
    # Inicializar IA
    initialize_ai()
    
    # Executar aplicação
    app.run(host='0.0.0.0', port=5000, debug=True)
