# Documentação Técnica - IA Treinável para Livros de Investimento

Esta documentação técnica descreve a arquitetura, componentes e implementação do sistema de IA treinável para processamento de livros sobre investimento e riqueza.

## Arquitetura do Sistema

O sistema foi projetado com uma arquitetura modular que separa as diferentes responsabilidades em componentes independentes:

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Interfaces de  │     │    Modelo de    │     │ Processamento   │
│    Usuário      │────▶│       IA        │────▶│    de Dados     │
│ (CLI e Web App) │     │                 │     │                 │
└─────────────────┘     └─────────────────┘     └─────────────────┘
                               │  ▲                     │  ▲
                               │  │                     │  │
                               ▼  │                     ▼  │
                        ┌─────────────────┐     ┌─────────────────┐
                        │   Módulos de    │     │   Sistema de    │
                        │  Recuperação e  │◀───▶│  Armazenamento  │
                        │    Geração      │     │                 │
                        └─────────────────┘     └─────────────────┘
```

### Componentes Principais

1. **Interfaces de Usuário**
   - Interface de Linha de Comando (CLI)
   - Aplicação Web (Flask)

2. **Modelo de IA**
   - Coordenador central do sistema
   - Gerencia o fluxo de dados entre componentes

3. **Processamento de Dados**
   - Importação de documentos
   - Processamento de texto
   - Geração de embeddings

4. **Módulos de Recuperação e Geração**
   - Recuperação de informações relevantes
   - Geração de respostas contextuais

5. **Sistema de Armazenamento**
   - Armazenamento de documentos
   - Índices de busca vetorial
   - Metadados e configurações

## Fluxos de Dados

### Fluxo de Importação e Treinamento

1. O usuário fornece documentos através da interface
2. O sistema importa e extrai texto dos documentos
3. O texto é processado (tokenização, limpeza, segmentação)
4. Embeddings são gerados para cada segmento de texto
5. Os embeddings são indexados para busca rápida
6. Metadados são armazenados para referência futura

### Fluxo de Consulta

1. O usuário faz uma pergunta através da interface
2. A pergunta é processada e transformada em embedding
3. O sistema busca segmentos de texto relevantes usando similaridade vetorial
4. Os segmentos recuperados são formatados como contexto
5. O modelo gera uma resposta baseada no contexto recuperado
6. A resposta é apresentada ao usuário com citações das fontes

## Implementação Detalhada

### Módulo de Importação (importer.py)

Responsável por extrair texto de diferentes formatos de arquivo:

```python
class DocumentImporter:
    def import_file(self, file_path, metadata=None):
        """Importa um arquivo e extrai seu texto."""
        file_ext = os.path.splitext(file_path)[1].lower()
        
        if file_ext == '.pdf':
            return self._import_pdf(file_path, metadata)
        elif file_ext == '.docx':
            return self._import_docx(file_path, metadata)
        elif file_ext == '.txt':
            return self._import_txt(file_path, metadata)
        else:
            raise ValueError(f"Formato de arquivo não suportado: {file_ext}")
```

### Módulo de Processamento (processor.py)

Processa o texto extraído para prepará-lo para análise:

```python
class TextProcessor:
    def process_text(self, text):
        """Processa um texto para análise."""
        # Limpeza básica
        text = self._clean_text(text)
        
        # Tokenização em sentenças
        sentences = self._tokenize_sentences(text)
        
        # Segmentação em blocos
        segments = self._create_segments(sentences)
        
        # Extração de palavras-chave
        keywords = self._extract_keywords(text)
        
        return {
            "segments": segments,
            "keywords": keywords
        }
```

### Módulo de Embeddings (embedder.py)

Gera representações vetoriais do texto para busca semântica:

```python
class TextEmbedder:
    def __init__(self, embeddings_dir, model_name="all-MiniLM-L6-v2"):
        """Inicializa o gerador de embeddings."""
        self.embeddings_dir = embeddings_dir
        self.model_name = model_name
        self.model = self._load_embedding_model()
        self.index = None
    
    def generate_embedding(self, text):
        """Gera um embedding para um texto."""
        return self.model.encode(text)
    
    def build_index(self, embeddings, ids):
        """Constrói um índice de busca para os embeddings."""
        import faiss
        
        # Converter para formato numpy
        embeddings_np = np.array(embeddings).astype('float32')
        
        # Criar índice
        dimension = embeddings_np.shape[1]
        index = faiss.IndexFlatL2(dimension)
        index.add(embeddings_np)
        
        # Armazenar mapeamento de IDs
        self.id_mapping = ids
        self.index = index
        
        return index
```

### Módulo de Recuperação (retriever.py)

Recupera informações relevantes para uma consulta:

```python
class Retriever:
    def __init__(self, embedder, document_store):
        """Inicializa o recuperador de informações."""
        self.embedder = embedder
        self.document_store = document_store
    
    def retrieve(self, query, top_k=5):
        """Recupera os segmentos mais relevantes para uma consulta."""
        # Gerar embedding da consulta
        query_embedding = self.embedder.generate_embedding(query)
        
        # Buscar segmentos similares
        similar_segments = self.embedder.search_similar(query_embedding, top_k)
        
        # Recuperar texto completo dos segmentos
        results = []
        for segment in similar_segments:
            segment_id = segment["segment_id"]
            doc_id, seg_num = self._parse_segment_id(segment_id)
            
            # Recuperar documento e segmento
            document = self.document_store.get_document(doc_id)
            if document:
                segment_text = document["segments"][seg_num]
                
                # Adicionar ao resultado
                results.append({
                    "segment_id": segment_id,
                    "doc_id": doc_id,
                    "similarity": segment["similarity"],
                    "text": segment_text,
                    "metadata": document.get("metadata", {})
                })
        
        return results
```

### Módulo de Geração (generator.py)

Gera respostas baseadas no contexto recuperado:

```python
class ResponseGenerator:
    def __init__(self, config=None):
        """Inicializa o gerador de respostas."""
        self.config = config or {}
        self.model_type = self.config.get("model_type", "local")
        
        if self.model_type == "openai":
            self._setup_openai()
        else:
            self._setup_local_model()
    
    def generate_response(self, query, context_segments):
        """Gera uma resposta para a consulta com base no contexto."""
        # Formatar contexto
        formatted_context = self._format_context(context_segments)
        
        # Construir prompt
        prompt = self._build_prompt(query, formatted_context)
        
        # Gerar resposta
        if self.model_type == "openai":
            response = self._generate_with_openai(prompt)
        else:
            response = self._generate_with_local_model(prompt)
        
        return {
            "query": query,
            "response": response,
            "sources": self._format_sources(context_segments)
        }
```

### Modelo Principal (model.py)

Coordena todos os componentes do sistema:

```python
class TrainableAI:
    def __init__(self, pipeline, config=None):
        """Inicializa a IA treinável."""
        self.pipeline = pipeline
        self.config = config or {}
        
        # Inicializar componentes
        self.retriever = Retriever(pipeline.embedder, pipeline.document_store)
        self.generator = ResponseGenerator(self.config.get("generator_config"))
        
        # Histórico de treinamento
        self.training_history = []
    
    def import_and_process_file(self, file_path, metadata=None):
        """Importa e processa um arquivo."""
        return self.pipeline.process_file(file_path, metadata)
    
    def train_model(self, documents=None):
        """Treina o modelo com os documentos especificados."""
        # Registrar treinamento
        training_record = {
            "timestamp": time.time(),
            "document_ids": documents or list(self.pipeline.documents.keys())
        }
        self.training_history.append(training_record)
        
        # Treinar embeddings
        embedding_result = self.pipeline.train_embeddings(documents)
        
        # Treinar modelo de linguagem (se configurado)
        fine_tuning_result = {"status": "skipped"}
        if self.config.get("enable_fine_tuning", False):
            fine_tuning_result = self.pipeline.fine_tune_language_model(documents)
        
        return {
            "embedding_training": embedding_result,
            "fine_tuning": fine_tuning_result
        }
    
    def answer_question(self, question, top_k=5):
        """Responde a uma pergunta com base nos documentos importados."""
        # Recuperar informações relevantes
        relevant_info = self.retriever.retrieve(question, top_k)
        
        # Gerar resposta
        response_data = self.generator.generate_response(question, relevant_info)
        
        return response_data
```

## Detalhes de Implementação

### Armazenamento de Dados

O sistema utiliza uma combinação de:

- **Sistema de arquivos**: Para armazenar documentos originais e processados
- **Índices vetoriais**: Para busca eficiente de similaridade (FAISS)
- **Arquivos JSON**: Para metadados e configurações

### Otimizações

1. **Segmentação Inteligente**
   - Documentos são divididos em segmentos semânticos
   - Tamanho dos segmentos é ajustado para equilibrar contexto e precisão

2. **Indexação Eficiente**
   - Uso de FAISS para busca vetorial de alta performance
   - Índices otimizados para equilibrar velocidade e precisão

3. **Processamento em Lote**
   - Documentos grandes são processados em lotes para economizar memória
   - Embeddings são gerados em paralelo quando possível

### Extensibilidade

O sistema foi projetado para ser facilmente extensível:

1. **Modelos Plugáveis**
   - Suporte para diferentes modelos de embeddings
   - Integração com APIs externas ou modelos locais

2. **Pipeline Configurável**
   - Cada etapa do processamento pode ser personalizada
   - Novos processadores podem ser adicionados ao pipeline

3. **Interfaces Extensíveis**
   - Novas interfaces podem ser adicionadas (API REST, GUI desktop)
   - Comandos adicionais podem ser implementados na CLI

## Considerações de Desempenho

### Requisitos de Hardware

- **Mínimo**: 4GB RAM, 2 núcleos de CPU, 10GB de espaço em disco
- **Recomendado**: 8GB+ RAM, 4+ núcleos de CPU, SSD com 20GB+ de espaço

### Escalabilidade

- O sistema pode processar até ~1000 documentos em configuração padrão
- Para volumes maiores, recomenda-se:
  - Usar banco de dados externo para metadados
  - Implementar sharding de índices FAISS
  - Configurar processamento distribuído

### Otimização de Memória

- Documentos são carregados sob demanda para economizar memória
- Embeddings são armazenados em formato otimizado
- Limpeza periódica de cache para liberar recursos

## Limitações Técnicas

1. **Processamento de PDF**
   - PDFs com estruturas complexas podem não ser processados corretamente
   - Tabelas e gráficos são ignorados no processamento atual

2. **Tamanho do Contexto**
   - Há um limite para o tamanho do contexto que pode ser usado na geração de respostas
   - Perguntas muito amplas podem não capturar todo o contexto relevante

3. **Modelos Locais**
   - Modelos locais têm desempenho inferior a APIs como OpenAI
   - Requerem mais recursos computacionais

## Segurança e Privacidade

- Todos os dados permanecem no dispositivo local do usuário
- Nenhum dado é enviado para servidores externos (exceto se configurado para usar APIs)
- Senhas e chaves de API são armazenadas de forma segura

## Referências

- [Sentence Transformers](https://www.sbert.net/)
- [FAISS](https://github.com/facebookresearch/faiss)
- [NLTK](https://www.nltk.org/)
- [Flask](https://flask.palletsprojects.com/)
- [PyPDF2](https://pypdf2.readthedocs.io/)
- [python-docx](https://python-docx.readthedocs.io/)
