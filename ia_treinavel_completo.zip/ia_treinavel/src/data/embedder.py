#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo de geração de embeddings para a IA treinável.
Responsável por criar representações vetoriais dos textos processados.
"""

import os
import json
import logging
import numpy as np
from typing import Dict, List, Optional, Tuple, Any, Union
from pathlib import Path
import pickle

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('embedder')

class TextEmbedder:
    """Classe para geração de embeddings de texto."""
    
    def __init__(self, embeddings_dir: str, model_name: str = 'all-MiniLM-L6-v2'):
        """
        Inicializa o gerador de embeddings.
        
        Args:
            embeddings_dir: Diretório para armazenar os embeddings
            model_name: Nome do modelo de embedding a ser usado
        """
        self.embeddings_dir = Path(embeddings_dir)
        self.embeddings_dir.mkdir(parents=True, exist_ok=True)
        self.model_name = model_name
        
        # Carregar modelo de embedding
        self.model = self._load_embedding_model()
    
    def _load_embedding_model(self):
        """
        Carrega o modelo de embedding.
        
        Returns:
            Modelo de embedding
        """
        try:
            from sentence_transformers import SentenceTransformer
            
            logger.info(f"Carregando modelo de embedding: {self.model_name}")
            model = SentenceTransformer(self.model_name)
            logger.info(f"Modelo de embedding carregado com sucesso")
            return model
        except ImportError:
            logger.error("sentence-transformers não está instalado. Instale com: pip install sentence-transformers")
            raise
    
    def generate_embedding(self, text: str) -> np.ndarray:
        """
        Gera embedding para um texto.
        
        Args:
            text: Texto para gerar embedding
            
        Returns:
            Vetor de embedding
        """
        if not text or not text.strip():
            logger.warning("Texto vazio fornecido para geração de embedding")
            # Retornar vetor de zeros com o tamanho correto
            return np.zeros(384)  # Tamanho padrão para 'all-MiniLM-L6-v2'
        
        # Gerar embedding
        embedding = self.model.encode(text)
        return embedding
    
    def generate_segment_embeddings(self, segments: List[str], doc_id: str) -> Dict[str, np.ndarray]:
        """
        Gera embeddings para uma lista de segmentos de texto.
        
        Args:
            segments: Lista de segmentos de texto
            doc_id: ID do documento
            
        Returns:
            Dicionário com IDs de segmentos e seus embeddings
        """
        if not segments:
            logger.warning(f"Lista de segmentos vazia para o documento {doc_id}")
            return {}
        
        embeddings = {}
        
        # Gerar embeddings para cada segmento
        for i, segment in enumerate(segments):
            segment_id = f"{doc_id}_seg_{i}"
            embedding = self.generate_embedding(segment)
            embeddings[segment_id] = embedding
        
        logger.info(f"Gerados {len(embeddings)} embeddings para o documento {doc_id}")
        return embeddings
    
    def save_embeddings(self, embeddings: Dict[str, np.ndarray], doc_id: str) -> str:
        """
        Salva embeddings em arquivo.
        
        Args:
            embeddings: Dicionário com IDs de segmentos e seus embeddings
            doc_id: ID do documento
            
        Returns:
            Caminho do arquivo de embeddings
        """
        # Criar diretório para o documento se não existir
        doc_dir = self.embeddings_dir / doc_id
        doc_dir.mkdir(exist_ok=True)
        
        # Salvar embeddings
        embeddings_file = doc_dir / "embeddings.pkl"
        with open(embeddings_file, 'wb') as f:
            pickle.dump(embeddings, f)
        
        # Salvar metadados
        metadata = {
            "doc_id": doc_id,
            "model_name": self.model_name,
            "segment_count": len(embeddings),
            "embedding_dim": next(iter(embeddings.values())).shape[0] if embeddings else 0,
            "segments": list(embeddings.keys())
        }
        
        metadata_file = doc_dir / "metadata.json"
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Embeddings salvos para o documento {doc_id}: {embeddings_file}")
        return str(embeddings_file)
    
    def load_embeddings(self, doc_id: str) -> Dict[str, np.ndarray]:
        """
        Carrega embeddings de um documento.
        
        Args:
            doc_id: ID do documento
            
        Returns:
            Dicionário com IDs de segmentos e seus embeddings
        """
        embeddings_file = self.embeddings_dir / doc_id / "embeddings.pkl"
        if not embeddings_file.exists():
            raise FileNotFoundError(f"Embeddings não encontrados para o documento {doc_id}")
        
        with open(embeddings_file, 'rb') as f:
            embeddings = pickle.load(f)
        
        logger.info(f"Embeddings carregados para o documento {doc_id}: {len(embeddings)} segmentos")
        return embeddings
    
    def get_embedding_metadata(self, doc_id: str) -> Dict:
        """
        Obtém metadados dos embeddings de um documento.
        
        Args:
            doc_id: ID do documento
            
        Returns:
            Dicionário com metadados
        """
        metadata_file = self.embeddings_dir / doc_id / "metadata.json"
        if not metadata_file.exists():
            raise FileNotFoundError(f"Metadados de embeddings não encontrados para o documento {doc_id}")
        
        with open(metadata_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def process_document(self, doc_id: str, segments: List[str]) -> Dict:
        """
        Processa um documento gerando embeddings para seus segmentos.
        
        Args:
            doc_id: ID do documento
            segments: Lista de segmentos de texto
            
        Returns:
            Dicionário com metadados dos embeddings
        """
        # Gerar embeddings
        embeddings = self.generate_segment_embeddings(segments, doc_id)
        
        # Salvar embeddings
        self.save_embeddings(embeddings, doc_id)
        
        # Retornar metadados
        return self.get_embedding_metadata(doc_id)
    
    def create_faiss_index(self, embeddings_list: List[Dict[str, np.ndarray]]) -> Tuple[Any, Dict[int, str]]:
        """
        Cria um índice FAISS para busca eficiente de embeddings.
        
        Args:
            embeddings_list: Lista de dicionários de embeddings
            
        Returns:
            Tupla (índice FAISS, mapeamento de IDs)
        """
        try:
            import faiss
        except ImportError:
            logger.error("FAISS não está instalado. Instale com: pip install faiss-cpu ou faiss-gpu")
            raise
        
        # Extrair todos os embeddings e IDs
        all_embeddings = []
        id_mapping = {}
        
        idx = 0
        for embeddings_dict in embeddings_list:
            for segment_id, embedding in embeddings_dict.items():
                all_embeddings.append(embedding)
                id_mapping[idx] = segment_id
                idx += 1
        
        if not all_embeddings:
            logger.warning("Nenhum embedding fornecido para criar índice FAISS")
            return None, {}
        
        # Converter para array numpy
        embeddings_array = np.array(all_embeddings).astype('float32')
        
        # Criar índice
        dimension = embeddings_array.shape[1]
        index = faiss.IndexFlatL2(dimension)
        index.add(embeddings_array)
        
        logger.info(f"Índice FAISS criado com {len(all_embeddings)} embeddings de dimensão {dimension}")
        return index, id_mapping
    
    def save_faiss_index(self, index, id_mapping: Dict[int, str], index_name: str = "corpus_index") -> str:
        """
        Salva um índice FAISS e seu mapeamento de IDs.
        
        Args:
            index: Índice FAISS
            id_mapping: Mapeamento de IDs
            index_name: Nome do índice
            
        Returns:
            Caminho do diretório do índice
        """
        try:
            import faiss
        except ImportError:
            logger.error("FAISS não está instalado. Instale com: pip install faiss-cpu ou faiss-gpu")
            raise
        
        # Criar diretório para o índice
        index_dir = self.embeddings_dir / "indices" / index_name
        index_dir.mkdir(parents=True, exist_ok=True)
        
        # Salvar índice
        index_file = index_dir / "index.faiss"
        faiss.write_index(index, str(index_file))
        
        # Salvar mapeamento de IDs
        mapping_file = index_dir / "id_mapping.pkl"
        with open(mapping_file, 'wb') as f:
            pickle.dump(id_mapping, f)
        
        # Salvar metadados
        metadata = {
            "index_name": index_name,
            "vector_count": index.ntotal,
            "dimension": index.d,
            "created_at": str(Path(index_file).stat().st_mtime)
        }
        
        metadata_file = index_dir / "metadata.json"
        with open(metadata_file, 'w', encoding='utf-8') as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        
        logger.info(f"Índice FAISS salvo: {index_file}")
        return str(index_dir)
    
    def load_faiss_index(self, index_name: str = "corpus_index") -> Tuple[Any, Dict[int, str]]:
        """
        Carrega um índice FAISS e seu mapeamento de IDs.
        
        Args:
            index_name: Nome do índice
            
        Returns:
            Tupla (índice FAISS, mapeamento de IDs)
        """
        try:
            import faiss
        except ImportError:
            logger.error("FAISS não está instalado. Instale com: pip install faiss-cpu ou faiss-gpu")
            raise
        
        # Verificar se o índice existe
        index_dir = self.embeddings_dir / "indices" / index_name
        index_file = index_dir / "index.faiss"
        mapping_file = index_dir / "id_mapping.pkl"
        
        if not index_file.exists() or not mapping_file.exists():
            raise FileNotFoundError(f"Índice FAISS não encontrado: {index_name}")
        
        # Carregar índice
        index = faiss.read_index(str(index_file))
        
        # Carregar mapeamento de IDs
        with open(mapping_file, 'rb') as f:
            id_mapping = pickle.load(f)
        
        logger.info(f"Índice FAISS carregado: {index_file}")
        return index, id_mapping
    
    def search_similar(self, query: str, index, id_mapping: Dict[int, str], top_k: int = 5) -> List[Dict]:
        """
        Busca segmentos similares a uma consulta.
        
        Args:
            query: Texto da consulta
            index: Índice FAISS
            id_mapping: Mapeamento de IDs
            top_k: Número de resultados a retornar
            
        Returns:
            Lista de dicionários com IDs de segmentos e scores de similaridade
        """
        # Gerar embedding da consulta
        query_embedding = self.generate_embedding(query)
        query_embedding = np.array([query_embedding]).astype('float32')
        
        # Buscar no índice
        distances, indices = index.search(query_embedding, top_k)
        
        # Formatar resultados
        results = []
        for i, idx in enumerate(indices[0]):
            if idx < 0 or idx >= len(id_mapping):
                continue
                
            segment_id = id_mapping[idx]
            distance = distances[0][i]
            similarity = 1.0 / (1.0 + distance)  # Converter distância em similaridade
            
            results.append({
                "segment_id": segment_id,
                "similarity": float(similarity),
                "distance": float(distance)
            })
        
        return results


# Função de conveniência para criar um embedder com configuração padrão
def create_embedder(base_dir: str = None, model_name: str = 'all-MiniLM-L6-v2') -> TextEmbedder:
    """
    Cria um gerador de embeddings com configuração padrão.
    
    Args:
        base_dir: Diretório base para armazenar dados (opcional)
        model_name: Nome do modelo de embedding (opcional)
        
    Returns:
        Instância de TextEmbedder
    """
    if not base_dir:
        base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data')
    
    embeddings_dir = os.path.join(base_dir, 'embeddings')
    
    return TextEmbedder(embeddings_dir, model_name)


# Exemplo de uso
if __name__ == "__main__":
    # Criar embedder
    embedder = create_embedder()
    
    # Gerar embedding para um texto de exemplo
    text = "Investir em ações é uma forma de se tornar sócio de empresas e participar dos seus lucros."
    embedding = embedder.generate_embedding(text)
    
    print(f"Dimensão do embedding: {embedding.shape}")
    print(f"Primeiros 5 valores: {embedding[:5]}")
    
    # Gerar embeddings para segmentos
    segments = [
        "Investir em ações é uma forma de se tornar sócio de empresas.",
        "Existem diferentes estratégias de investimento, como buy and hold.",
        "Warren Buffett é considerado um dos maiores investidores de todos os tempos."
    ]
    
    embeddings = embedder.generate_segment_embeddings(segments, "exemplo_doc")
    print(f"Gerados {len(embeddings)} embeddings para os segmentos")
