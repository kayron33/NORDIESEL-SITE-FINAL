#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo principal da IA treinável.
Integra os componentes de recuperação, geração e treinamento.
"""

import os
import json
import logging
from typing import Dict, List, Optional, Tuple, Any, Union
from pathlib import Path

# Importar módulos locais
from .retriever import InformationRetriever, create_retriever
from .generator import ResponseGenerator, create_generator
from .trainer import ModelTrainer, create_trainer

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('ai_model')

class TrainableAI:
    """Classe principal da IA treinável que integra todos os componentes."""
    
    def __init__(self, data_pipeline, base_dir: str = None):
        """
        Inicializa a IA treinável.
        
        Args:
            data_pipeline: Pipeline de dados
            base_dir: Diretório base para armazenar dados e modelos (opcional)
        """
        if not base_dir:
            base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..')
        
        self.base_dir = Path(base_dir)
        self.data_pipeline = data_pipeline
        
        # Inicializar componentes
        self.trainer = create_trainer(os.path.join(base_dir, 'models'), data_pipeline)
        
        # Obter configurações atuais
        model_config = self.trainer.get_current_models()
        
        # Inicializar recuperador e gerador
        self.retriever = create_retriever(data_pipeline, model_config.get("current_index", "corpus_index"))
        self.generator = create_generator(model_config.get("language_model", "gpt-3.5-turbo"))
        
        # Configurar prompt do sistema
        if model_config.get("system_prompt"):
            self.generator.set_system_prompt(model_config["system_prompt"])
    
    def answer_question(self, question: str, top_k: int = 5) -> Dict:
        """
        Responde a uma pergunta usando o modelo treinado.
        
        Args:
            question: Pergunta do usuário
            top_k: Número de resultados a recuperar
            
        Returns:
            Dicionário com resposta e fontes
        """
        # Recuperar informações relevantes
        results = self.retriever.retrieve(question, top_k)
        
        # Se não houver resultados, tentar com palavras-chave
        if not results:
            logger.info("Nenhum resultado encontrado, tentando com palavras-chave")
            # Extrair palavras-chave da pergunta
            try:
                keywords = self.data_pipeline.processor.extract_keywords(question)
                if keywords:
                    results = self.retriever.retrieve_by_keywords(keywords, top_k)
            except Exception as e:
                logger.error(f"Erro ao extrair palavras-chave: {e}")
        
        # Gerar resposta com fontes
        response_data = self.generator.generate_response_with_sources(question, results)
        
        logger.info(f"Resposta gerada para a pergunta: '{question}'")
        return response_data
    
    def answer_with_context(self, question: str, top_k: int = 5, context_size: int = 1) -> Dict:
        """
        Responde a uma pergunta com contexto adicional.
        
        Args:
            question: Pergunta do usuário
            top_k: Número de resultados a recuperar
            context_size: Número de segmentos de contexto antes/depois
            
        Returns:
            Dicionário com resposta e fontes
        """
        # Recuperar informações relevantes com contexto
        results = self.retriever.retrieve_with_context(question, top_k, context_size)
        
        # Gerar resposta com fontes
        response_data = self.generator.generate_response_with_sources(question, results)
        
        # Adicionar contexto completo à resposta
        for i, result in enumerate(results):
            if "context_full" in result:
                response_data["sources"][i]["context"] = result["context_full"]
        
        logger.info(f"Resposta com contexto gerada para a pergunta: '{question}'")
        return response_data
    
    def train_model(self, documents: List[str] = None) -> Dict:
        """
        Treina o modelo com novos documentos.
        
        Args:
            documents: Lista de IDs de documentos para treinar (opcional)
            
        Returns:
            Dicionário com resultados do treinamento
        """
        # Treinar modelo de embeddings
        embedding_result = self.trainer.train_embedding_model(documents)
        
        # Atualizar recuperador com novo índice
        if embedding_result.get("status") == "success" and embedding_result.get("index_name"):
            self.retriever = create_retriever(self.data_pipeline, embedding_result["index_name"])
        
        # Tentar fine-tuning se habilitado
        fine_tuning_result = {"status": "skipped", "message": "Fine-tuning não executado"}
        model_config = self.trainer.get_current_models()
        if model_config.get("fine_tuning_enabled", False):
            fine_tuning_result = self.trainer.fine_tune_language_model()
        
        logger.info(f"Treinamento concluído: {embedding_result.get('status')}")
        return {
            "embedding_training": embedding_result,
            "fine_tuning": fine_tuning_result
        }
    
    def import_and_process_file(self, file_path: str, metadata: Dict = None) -> Dict:
        """
        Importa e processa um arquivo, adicionando-o à base de conhecimento.
        
        Args:
            file_path: Caminho para o arquivo
            metadata: Metadados associados ao arquivo (opcional)
            
        Returns:
            Dicionário com resultados do processamento
        """
        try:
            # Processar arquivo
            doc_id = self.data_pipeline.process_file(file_path, metadata)
            
            # Obter informações do documento
            doc_info = self.data_pipeline.get_document_info(doc_id)
            
            logger.info(f"Arquivo importado e processado: {file_path} -> {doc_id}")
            return {
                "status": "success",
                "doc_id": doc_id,
                "info": doc_info
            }
        except Exception as e:
            logger.error(f"Erro ao importar e processar arquivo: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def import_and_process_directory(self, dir_path: str, metadata_template: Dict = None, 
                                    recursive: bool = False) -> Dict:
        """
        Importa e processa todos os arquivos de um diretório.
        
        Args:
            dir_path: Caminho para o diretório
            metadata_template: Modelo de metadados para todos os arquivos (opcional)
            recursive: Se deve processar arquivos em subdiretórios
            
        Returns:
            Dicionário com resultados do processamento
        """
        try:
            # Processar diretório
            doc_ids = self.data_pipeline.process_directory(dir_path, metadata_template, recursive)
            
            # Obter informações dos documentos
            docs_info = []
            for doc_id in doc_ids:
                try:
                    doc_info = self.data_pipeline.get_document_info(doc_id)
                    docs_info.append(doc_info)
                except Exception as e:
                    logger.error(f"Erro ao obter informações do documento {doc_id}: {e}")
            
            logger.info(f"Diretório importado e processado: {dir_path} -> {len(doc_ids)} documentos")
            return {
                "status": "success",
                "doc_count": len(doc_ids),
                "doc_ids": doc_ids,
                "docs_info": docs_info
            }
        except Exception as e:
            logger.error(f"Erro ao importar e processar diretório: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def update_system_prompt(self, new_prompt: str) -> Dict:
        """
        Atualiza o prompt de sistema.
        
        Args:
            new_prompt: Novo prompt de sistema
            
        Returns:
            Dicionário com status da atualização
        """
        try:
            # Atualizar no treinador
            self.trainer.update_system_prompt(new_prompt)
            
            # Atualizar no gerador
            self.generator.set_system_prompt(new_prompt)
            
            logger.info("Prompt de sistema atualizado")
            return {
                "status": "success",
                "message": "Prompt de sistema atualizado com sucesso"
            }
        except Exception as e:
            logger.error(f"Erro ao atualizar prompt de sistema: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def get_model_info(self) -> Dict:
        """
        Obtém informações sobre o modelo atual.
        
        Returns:
            Dicionário com informações do modelo
        """
        model_config = self.trainer.get_current_models()
        training_history = self.trainer.get_training_history()
        
        # Contar documentos processados
        doc_count = 0
        try:
            docs = self.data_pipeline.list_processed_documents()
            doc_count = len(docs)
        except Exception as e:
            logger.error(f"Erro ao contar documentos: {e}")
        
        return {
            "models": model_config,
            "document_count": doc_count,
            "training_history": training_history[-5:] if training_history else [],  # Últimos 5 treinamentos
            "total_trainings": len(training_history)
        }


# Função de conveniência para criar uma IA treinável com configuração padrão
def create_trainable_ai(data_pipeline, base_dir: str = None) -> TrainableAI:
    """
    Cria uma IA treinável com configuração padrão.
    
    Args:
        data_pipeline: Pipeline de dados
        base_dir: Diretório base para armazenar dados e modelos (opcional)
        
    Returns:
        Instância de TrainableAI
    """
    return TrainableAI(data_pipeline, base_dir)


# Exemplo de uso
if __name__ == "__main__":
    # Importar pipeline
    from src.data.pipeline import create_pipeline
    
    # Criar pipeline e IA treinável
    pipeline = create_pipeline()
    ai = create_trainable_ai(pipeline)
    
    # Responder a uma pergunta
    question = "Quais são as melhores estratégias de investimento para longo prazo?"
    response = ai.answer_question(question)
    
    # Mostrar resposta
    print(f"Pergunta: {question}")
    print(f"Resposta: {response['response']}")
    print("\nFontes:")
    for source in response['sources']:
        print(f"- {source.get('title', 'Desconhecido')}")
