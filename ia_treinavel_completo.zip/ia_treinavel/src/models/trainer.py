#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo de treinamento para a IA treinável.
Responsável por treinar e atualizar o modelo com novos dados.
"""

import os
import json
import logging
import time
from typing import Dict, List, Optional, Tuple, Any, Union
from pathlib import Path
import pickle

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('trainer')

class ModelTrainer:
    """Classe para treinamento e atualização do modelo de IA."""
    
    def __init__(self, models_dir: str, data_pipeline=None):
        """
        Inicializa o treinador de modelos.
        
        Args:
            models_dir: Diretório para armazenar modelos treinados
            data_pipeline: Pipeline de dados (opcional)
        """
        self.models_dir = Path(models_dir)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.data_pipeline = data_pipeline
        
        # Carregar configurações de treinamento
        self.config_file = self.models_dir / "training_config.json"
        self.config = self._load_config()
    
    def _load_config(self) -> Dict:
        """
        Carrega configurações de treinamento ou cria padrão.
        
        Returns:
            Dicionário de configurações
        """
        if self.config_file.exists():
            try:
                with open(self.config_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                logger.warning(f"Erro ao carregar configurações. Criando padrão.")
                return self._create_default_config()
        else:
            return self._create_default_config()
    
    def _create_default_config(self) -> Dict:
        """
        Cria configurações padrão de treinamento.
        
        Returns:
            Dicionário de configurações padrão
        """
        config = {
            "embedding_model": "all-MiniLM-L6-v2",
            "language_model": "gpt-3.5-turbo",
            "training_history": [],
            "fine_tuning": {
                "enabled": False,
                "base_model": "gpt-3.5-turbo-0613",
                "epochs": 3,
                "learning_rate": 0.0001
            },
            "retrieval": {
                "top_k": 5,
                "similarity_threshold": 0.7
            },
            "system_prompt": """
            Você é um assistente especializado em investimentos e finanças pessoais, treinado com dados de livros e materiais sobre esses temas.
            Seu objetivo é fornecer informações precisas e úteis, baseando-se apenas no contexto fornecido.
            
            Diretrizes:
            1. Responda apenas com base nas informações presentes no contexto fornecido.
            2. Se o contexto não contiver informações suficientes, admita que não tem informações suficientes.
            3. Não invente ou extrapole informações além do que está no contexto.
            4. Cite as fontes das informações quando disponíveis, usando os números de referência do contexto.
            5. Mantenha um tom profissional, educativo e imparcial.
            6. Evite dar conselhos financeiros específicos ou personalizados.
            7. Formate sua resposta de maneira clara e organizada.
            """
        }
        
        # Salvar configuração padrão
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        
        logger.info("Configurações padrão de treinamento criadas")
        return config
    
    def _save_config(self) -> None:
        """Salva as configurações de treinamento."""
        with open(self.config_file, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
        logger.info("Configurações de treinamento salvas")
    
    def update_config(self, new_config: Dict) -> None:
        """
        Atualiza as configurações de treinamento.
        
        Args:
            new_config: Novas configurações (parcial ou completa)
        """
        # Atualizar apenas os campos fornecidos
        for key, value in new_config.items():
            if isinstance(value, dict) and key in self.config and isinstance(self.config[key], dict):
                # Para dicionários aninhados, atualizar recursivamente
                self.config[key].update(value)
            else:
                # Para valores simples, substituir diretamente
                self.config[key] = value
        
        self._save_config()
        logger.info("Configurações de treinamento atualizadas")
    
    def train_embedding_model(self, documents: List[str] = None) -> Dict:
        """
        Treina ou atualiza o modelo de embeddings.
        
        Args:
            documents: Lista de IDs de documentos para treinar (opcional)
            
        Returns:
            Dicionário com resultados do treinamento
        """
        if not self.data_pipeline:
            logger.error("Pipeline de dados não configurado")
            return {"status": "error", "message": "Pipeline de dados não configurado"}
        
        start_time = time.time()
        
        try:
            # Se não foram especificados documentos, usar todos os documentos processados
            if not documents:
                documents = [doc["id"] for doc in self.data_pipeline.list_processed_documents()]
            
            if not documents:
                logger.warning("Nenhum documento disponível para treinamento")
                return {"status": "error", "message": "Nenhum documento disponível para treinamento"}
            
            # Construir índice de busca
            index_name = f"corpus_index_{int(time.time())}"
            index_dir = self.data_pipeline.build_search_index(index_name)
            
            # Registrar treinamento
            training_record = {
                "type": "embedding",
                "model": self.config["embedding_model"],
                "documents": documents,
                "index_name": index_name,
                "timestamp": time.time(),
                "duration_seconds": time.time() - start_time
            }
            
            self.config["training_history"].append(training_record)
            self.config["current_index"] = index_name
            self._save_config()
            
            logger.info(f"Modelo de embeddings treinado com {len(documents)} documentos")
            return {
                "status": "success",
                "model": self.config["embedding_model"],
                "index_name": index_name,
                "document_count": len(documents),
                "duration_seconds": time.time() - start_time
            }
        except Exception as e:
            logger.error(f"Erro ao treinar modelo de embeddings: {e}")
            return {"status": "error", "message": str(e)}
    
    def fine_tune_language_model(self, training_data: List[Dict] = None) -> Dict:
        """
        Realiza fine-tuning do modelo de linguagem.
        
        Args:
            training_data: Dados de treinamento (opcional)
            
        Returns:
            Dicionário com resultados do fine-tuning
        """
        if not self.config["fine_tuning"]["enabled"]:
            logger.info("Fine-tuning desabilitado nas configurações")
            return {"status": "skipped", "message": "Fine-tuning desabilitado nas configurações"}
        
        start_time = time.time()
        
        try:
            import openai
            
            # Verificar se a chave da API está configurada
            if not os.environ.get("OPENAI_API_KEY"):
                logger.warning("OPENAI_API_KEY não está configurada. Configure-a como variável de ambiente.")
                return {"status": "error", "message": "OPENAI_API_KEY não configurada"}
            
            # Se não foram fornecidos dados de treinamento, usar exemplos padrão
            if not training_data:
                training_data = self._generate_training_examples()
            
            if not training_data:
                logger.warning("Nenhum dado de treinamento disponível para fine-tuning")
                return {"status": "error", "message": "Nenhum dado de treinamento disponível"}
            
            # Preparar arquivo de treinamento
            training_file_path = self.models_dir / f"training_data_{int(time.time())}.jsonl"
            with open(training_file_path, 'w', encoding='utf-8') as f:
                for example in training_data:
                    f.write(json.dumps(example) + "\n")
            
            # Fazer upload do arquivo para a OpenAI
            with open(training_file_path, 'rb') as f:
                response = openai.File.create(
                    file=f,
                    purpose="fine-tune"
                )
            
            file_id = response.id
            
            # Iniciar job de fine-tuning
            response = openai.FineTuningJob.create(
                training_file=file_id,
                model=self.config["fine_tuning"]["base_model"],
                hyperparameters={
                    "n_epochs": self.config["fine_tuning"]["epochs"],
                    "learning_rate_multiplier": self.config["fine_tuning"]["learning_rate"]
                }
            )
            
            job_id = response.id
            
            # Registrar treinamento
            training_record = {
                "type": "fine_tuning",
                "base_model": self.config["fine_tuning"]["base_model"],
                "job_id": job_id,
                "file_id": file_id,
                "example_count": len(training_data),
                "timestamp": time.time(),
                "status": "submitted"
            }
            
            self.config["training_history"].append(training_record)
            self._save_config()
            
            logger.info(f"Job de fine-tuning iniciado: {job_id}")
            return {
                "status": "submitted",
                "job_id": job_id,
                "file_id": file_id,
                "example_count": len(training_data)
            }
        except Exception as e:
            logger.error(f"Erro ao realizar fine-tuning: {e}")
            return {"status": "error", "message": str(e)}
    
    def _generate_training_examples(self) -> List[Dict]:
        """
        Gera exemplos de treinamento a partir dos documentos processados.
        
        Returns:
            Lista de exemplos para fine-tuning
        """
        if not self.data_pipeline:
            logger.error("Pipeline de dados não configurado")
            return []
        
        examples = []
        
        try:
            # Obter documentos processados
            documents = self.data_pipeline.list_processed_documents()
            
            for doc in documents[:10]:  # Limitar a 10 documentos para não gerar muitos exemplos
                try:
                    # Obter segmentos do documento
                    doc_id = doc["id"]
                    segments = self.data_pipeline.processor.get_document_segments(doc_id)
                    
                    # Gerar exemplos a partir dos segmentos
                    for i, segment in enumerate(segments[:5]):  # Limitar a 5 segmentos por documento
                        # Criar uma pergunta fictícia baseada no conteúdo
                        question = self._generate_question_from_segment(segment)
                        
                        if question:
                            # Criar exemplo no formato esperado pela OpenAI
                            example = {
                                "messages": [
                                    {"role": "system", "content": self.config["system_prompt"]},
                                    {"role": "user", "content": question},
                                    {"role": "assistant", "content": segment}
                                ]
                            }
                            examples.append(example)
                except Exception as e:
                    logger.error(f"Erro ao gerar exemplos para o documento {doc['id']}: {e}")
                    continue
            
            logger.info(f"Gerados {len(examples)} exemplos de treinamento")
            return examples
        except Exception as e:
            logger.error(f"Erro ao gerar exemplos de treinamento: {e}")
            return []
    
    def _generate_question_from_segment(self, segment: str) -> str:
        """
        Gera uma pergunta fictícia baseada no conteúdo de um segmento.
        
        Args:
            segment: Texto do segmento
            
        Returns:
            Pergunta gerada
        """
        # Implementação simples para gerar perguntas
        # Em uma implementação real, poderia usar um modelo de linguagem para isso
        
        if not segment or len(segment) < 20:
            return ""
        
        # Extrair palavras-chave
        words = segment.split()
        if len(words) < 5:
            return ""
        
        # Identificar possíveis temas
        investment_terms = ["investimento", "ações", "bolsa", "mercado", "dinheiro", "finanças", 
                           "renda", "juros", "dividendos", "economia", "poupança", "risco"]
        
        found_terms = [word.lower() for word in words 
                      if any(term in word.lower() for term in investment_terms)]
        
        if not found_terms:
            return ""
        
        # Gerar pergunta baseada nos termos encontrados
        term = found_terms[0].replace(".", "").replace(",", "")
        
        templates = [
            f"O que é {term} e como funciona?",
            f"Quais são as principais estratégias relacionadas a {term}?",
            f"Como {term} pode ajudar a construir riqueza?",
            f"Quais são os riscos associados a {term}?",
            f"Explique o conceito de {term} para iniciantes."
        ]
        
        import random
        return random.choice(templates)
    
    def check_fine_tuning_status(self, job_id: str) -> Dict:
        """
        Verifica o status de um job de fine-tuning.
        
        Args:
            job_id: ID do job de fine-tuning
            
        Returns:
            Dicionário com status do job
        """
        try:
            import openai
            
            # Verificar se a chave da API está configurada
            if not os.environ.get("OPENAI_API_KEY"):
                logger.warning("OPENAI_API_KEY não está configurada. Configure-a como variável de ambiente.")
                return {"status": "error", "message": "OPENAI_API_KEY não configurada"}
            
            # Obter status do job
            response = openai.FineTuningJob.retrieve(job_id)
            
            # Atualizar registro de treinamento
            for record in self.config["training_history"]:
                if record.get("type") == "fine_tuning" and record.get("job_id") == job_id:
                    record["status"] = response.status
                    if response.status == "succeeded":
                        record["fine_tuned_model"] = response.fine_tuned_model
                        self.config["language_model"] = response.fine_tuned_model
                    
                    self._save_config()
                    break
            
            logger.info(f"Status do job de fine-tuning {job_id}: {response.status}")
            return {
                "job_id": job_id,
                "status": response.status,
                "fine_tuned_model": response.fine_tuned_model if response.status == "succeeded" else None
            }
        except Exception as e:
            logger.error(f"Erro ao verificar status do fine-tuning: {e}")
            return {"status": "error", "message": str(e)}
    
    def get_training_history(self) -> List[Dict]:
        """
        Obtém o histórico de treinamentos.
        
        Returns:
            Lista de registros de treinamento
        """
        return self.config["training_history"]
    
    def get_current_models(self) -> Dict:
        """
        Obtém informações sobre os modelos atuais.
        
        Returns:
            Dicionário com informações dos modelos
        """
        return {
            "embedding_model": self.config["embedding_model"],
            "language_model": self.config["language_model"],
            "current_index": self.config.get("current_index", ""),
            "fine_tuning_enabled": self.config["fine_tuning"]["enabled"],
            "system_prompt": self.config["system_prompt"]
        }
    
    def update_system_prompt(self, new_prompt: str) -> None:
        """
        Atualiza o prompt de sistema.
        
        Args:
            new_prompt: Novo prompt de sistema
        """
        self.config["system_prompt"] = new_prompt
        self._save_config()
        logger.info("Prompt de sistema atualizado")


# Função de conveniência para criar um treinador com configuração padrão
def create_trainer(models_dir: str = None, data_pipeline=None) -> ModelTrainer:
    """
    Cria um treinador de modelos com configuração padrão.
    
    Args:
        models_dir: Diretório para armazenar modelos
        data_pipeline: Pipeline de dados
        
    Returns:
        Instância de ModelTrainer
    """
    if not models_dir:
        models_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'models')
    
    return ModelTrainer(models_dir, data_pipeline)


# Exemplo de uso
if __name__ == "__main__":
    # Importar pipeline
    from src.data.pipeline import create_pipeline
    
    # Criar pipeline e treinador
    pipeline = create_pipeline()
    trainer = create_trainer(data_pipeline=pipeline)
    
    # Treinar modelo de embeddings
    result = trainer.train_embedding_model()
    
    # Mostrar resultado
    print(f"Resultado do treinamento: {result}")
    
    # Mostrar modelos atuais
    current_models = trainer.get_current_models()
    print(f"Modelos atuais: {current_models}")
