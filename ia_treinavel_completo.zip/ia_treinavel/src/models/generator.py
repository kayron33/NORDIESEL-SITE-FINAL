#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo de geração de respostas para a IA treinável.
Responsável por gerar respostas baseadas em informações recuperadas.
"""

import os
import json
import logging
from typing import Dict, List, Optional, Tuple, Any, Union
from pathlib import Path

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('generator')

class ResponseGenerator:
    """Classe para geração de respostas baseadas em informações recuperadas."""
    
    def __init__(self, model_name: str = "gpt-3.5-turbo"):
        """
        Inicializa o gerador de respostas.
        
        Args:
            model_name: Nome do modelo de linguagem a ser usado
        """
        self.model_name = model_name
        self.system_prompt = """
        Você é um assistente especializado em investimentos e finanças pessoais, treinado com dados de livros e materiais sobre esses temas.
        Seu objetivo é fornecer informações precisas e úteis, baseando-se apenas no contexto fornecido.
        
        Diretrizes:
        1. Responda apenas com base nas informações presentes no contexto fornecido.
        2. Se o contexto não contiver informações suficientes, admita que não tem informações suficientes.
        3. Não invente ou extrapole informações além do que está no contexto.
        4. Cite as fontes das informações quando disponíveis, usando os números de referência do contexto.
        5. Mantenha um tom profissional, educativo e imparcial.
        6. Evite dar conselhos financeiros específicos ou personalizados.
        7. Formate sua resposta de maneira clara e organizada.
        """
        
        # Inicializar o modelo de linguagem
        self._initialize_model()
    
    def _initialize_model(self):
        """Inicializa o modelo de linguagem."""
        try:
            import openai
            self.model_type = "openai"
            logger.info(f"Modelo OpenAI inicializado: {self.model_name}")
        except ImportError:
            try:
                from transformers import pipeline
                self.model_type = "huggingface"
                self.model = pipeline("text-generation", model=self.model_name)
                logger.info(f"Modelo Hugging Face inicializado: {self.model_name}")
            except ImportError:
                logger.warning("Nem OpenAI nem Hugging Face estão disponíveis. Usando modo de fallback.")
                self.model_type = "fallback"
    
    def generate_response(self, query: str, context: str) -> str:
        """
        Gera uma resposta para uma consulta com base no contexto fornecido.
        
        Args:
            query: Consulta do usuário
            context: Contexto com informações relevantes
            
        Returns:
            Resposta gerada
        """
        if not context:
            return "Não tenho informações suficientes para responder a essa pergunta com base nos dados disponíveis."
        
        # Preparar prompt completo
        user_prompt = f"""
        Consulta: {query}
        
        Contexto:
        {context}
        
        Com base apenas nas informações fornecidas no contexto acima, responda à consulta.
        """
        
        # Gerar resposta usando o modelo apropriado
        if self.model_type == "openai":
            return self._generate_with_openai(user_prompt)
        elif self.model_type == "huggingface":
            return self._generate_with_huggingface(user_prompt)
        else:
            return self._generate_fallback(query, context)
    
    def _generate_with_openai(self, prompt: str) -> str:
        """
        Gera resposta usando a API da OpenAI.
        
        Args:
            prompt: Prompt completo
            
        Returns:
            Resposta gerada
        """
        try:
            import openai
            
            # Verificar se a chave da API está configurada
            if not os.environ.get("OPENAI_API_KEY"):
                logger.warning("OPENAI_API_KEY não está configurada. Configure-a como variável de ambiente.")
                return self._generate_fallback("", "")
            
            # Criar mensagens para a API
            messages = [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": prompt}
            ]
            
            # Chamar a API
            response = openai.ChatCompletion.create(
                model=self.model_name,
                messages=messages,
                temperature=0.7,
                max_tokens=1000
            )
            
            # Extrair resposta
            return response.choices[0].message.content.strip()
        except Exception as e:
            logger.error(f"Erro ao gerar resposta com OpenAI: {e}")
            return self._generate_fallback("", "")
    
    def _generate_with_huggingface(self, prompt: str) -> str:
        """
        Gera resposta usando modelo do Hugging Face.
        
        Args:
            prompt: Prompt completo
            
        Returns:
            Resposta gerada
        """
        try:
            # Combinar system prompt e user prompt
            full_prompt = f"{self.system_prompt}\n\n{prompt}"
            
            # Gerar resposta
            result = self.model(
                full_prompt,
                max_length=1024,
                num_return_sequences=1,
                temperature=0.7
            )
            
            # Extrair e limpar resposta
            generated_text = result[0]["generated_text"]
            
            # Remover o prompt original da resposta
            response = generated_text[len(full_prompt):].strip()
            
            return response
        except Exception as e:
            logger.error(f"Erro ao gerar resposta com Hugging Face: {e}")
            return self._generate_fallback("", "")
    
    def _generate_fallback(self, query: str, context: str) -> str:
        """
        Gera uma resposta simples baseada no contexto quando os modelos não estão disponíveis.
        
        Args:
            query: Consulta do usuário
            context: Contexto com informações relevantes
            
        Returns:
            Resposta gerada
        """
        if not context:
            return "Não tenho informações suficientes para responder a essa pergunta."
        
        # Extrair os primeiros parágrafos do contexto
        paragraphs = context.split("\n\n")
        relevant_info = paragraphs[0]
        
        if len(paragraphs) > 1:
            relevant_info += "\n\n" + paragraphs[1]
        
        response = f"""
        Com base nas informações disponíveis:
        
        {relevant_info}
        
        Esta informação foi extraída diretamente do material fornecido. Para uma resposta mais elaborada, 
        configure um modelo de linguagem como OpenAI ou Hugging Face.
        """
        
        return response.strip()
    
    def generate_response_with_sources(self, query: str, results: List[Dict]) -> Dict:
        """
        Gera uma resposta com citação de fontes.
        
        Args:
            query: Consulta do usuário
            results: Resultados da recuperação de informações
            
        Returns:
            Dicionário com resposta e fontes
        """
        # Formatar contexto a partir dos resultados
        context_parts = []
        sources = []
        
        for i, result in enumerate(results):
            # Adicionar texto ao contexto
            text = result["text"]
            context_parts.append(f"[{i+1}] {text}")
            
            # Registrar fonte
            source = {}
            metadata = result.get("metadata", {})
            
            if metadata.get("title"):
                source["title"] = metadata["title"]
                if metadata.get("author"):
                    source["author"] = metadata["author"]
            
            if metadata.get("source"):
                source["path"] = metadata["source"]
            
            source["reference_id"] = i + 1
            sources.append(source)
        
        # Juntar contexto
        context = "\n\n".join(context_parts)
        
        # Gerar resposta
        response_text = self.generate_response(query, context)
        
        return {
            "query": query,
            "response": response_text,
            "sources": sources
        }
    
    def set_system_prompt(self, prompt: str) -> None:
        """
        Define um novo prompt de sistema.
        
        Args:
            prompt: Novo prompt de sistema
        """
        self.system_prompt = prompt
        logger.info("Prompt de sistema atualizado")
    
    def get_system_prompt(self) -> str:
        """
        Obtém o prompt de sistema atual.
        
        Returns:
            Prompt de sistema
        """
        return self.system_prompt


# Função de conveniência para criar um gerador com configuração padrão
def create_generator(model_name: str = "gpt-3.5-turbo") -> ResponseGenerator:
    """
    Cria um gerador de respostas com configuração padrão.
    
    Args:
        model_name: Nome do modelo de linguagem
        
    Returns:
        Instância de ResponseGenerator
    """
    return ResponseGenerator(model_name)


# Exemplo de uso
if __name__ == "__main__":
    # Criar gerador
    generator = create_generator()
    
    # Exemplo de consulta e contexto
    query = "Quais são as principais estratégias de investimento para iniciantes?"
    context = """
    [1] Para iniciantes no mercado de investimentos, é recomendável começar com uma estratégia conservadora, focando em renda fixa como Tesouro Direto e CDBs. Conforme o conhecimento aumenta, pode-se diversificar para fundos de investimento e, eventualmente, ações. (Fonte: "Investimentos Inteligentes" por Carlos Silva)
    
    [2] A estratégia buy and hold consiste em comprar ativos de qualidade e mantê-los por longos períodos, ignorando as flutuações de curto prazo do mercado. Esta abordagem é especialmente adequada para iniciantes por sua simplicidade e eficácia a longo prazo. (Fonte: "O Investidor Inteligente" por Benjamin Graham)
    
    [3] Diversificação é um princípio fundamental para reduzir riscos. Iniciantes devem distribuir seus investimentos entre diferentes classes de ativos, como renda fixa, ações, fundos imobiliários e, se possível, investimentos internacionais. (Fonte: "Princípios de Investimento" por Ana Rodrigues)
    """
    
    # Gerar resposta
    response = generator.generate_response(query, context)
    print(response)
