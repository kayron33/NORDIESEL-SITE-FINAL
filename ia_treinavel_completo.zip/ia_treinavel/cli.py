#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Interface de linha de comando (CLI) para a IA treinável.
Permite importar dados, treinar o modelo e fazer consultas.
"""

import os
import sys
import argparse
import json
import logging
from typing import Dict, List, Optional, Any
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('cli')

# Adicionar diretório pai ao path para importar módulos
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Importar módulos do projeto
from src.data.pipeline import create_pipeline
from src.models.model import create_trainable_ai

def setup_argparse() -> argparse.ArgumentParser:
    """
    Configura o parser de argumentos de linha de comando.
    
    Returns:
        Parser configurado
    """
    parser = argparse.ArgumentParser(
        description='IA Treinável para Livros de Investimento e Riqueza',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso:
  # Importar um arquivo
  python cli.py import --file /caminho/para/livro.pdf --title "O Investidor Inteligente" --author "Benjamin Graham"
  
  # Importar um diretório
  python cli.py import --dir /caminho/para/livros --recursive
  
  # Treinar o modelo
  python cli.py train
  
  # Fazer uma pergunta
  python cli.py ask "Quais são as melhores estratégias de investimento para longo prazo?"
  
  # Obter informações sobre o modelo
  python cli.py info
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Comando a executar')
    
    # Comando: import
    import_parser = subparsers.add_parser('import', help='Importar dados para o sistema')
    import_group = import_parser.add_mutually_exclusive_group(required=True)
    import_group.add_argument('--file', type=str, help='Caminho para o arquivo a ser importado')
    import_group.add_argument('--dir', type=str, help='Caminho para o diretório a ser importado')
    import_parser.add_argument('--title', type=str, help='Título do documento')
    import_parser.add_argument('--author', type=str, help='Autor do documento')
    import_parser.add_argument('--category', type=str, help='Categoria do documento')
    import_parser.add_argument('--recursive', action='store_true', help='Importar diretório recursivamente')
    
    # Comando: train
    train_parser = subparsers.add_parser('train', help='Treinar o modelo com os dados importados')
    train_parser.add_argument('--docs', type=str, nargs='+', help='IDs dos documentos para treinar (opcional)')
    
    # Comando: ask
    ask_parser = subparsers.add_parser('ask', help='Fazer uma pergunta ao modelo')
    ask_parser.add_argument('question', type=str, help='Pergunta a ser feita')
    ask_parser.add_argument('--context', action='store_true', help='Incluir contexto adicional na resposta')
    ask_parser.add_argument('--top-k', type=int, default=5, help='Número de resultados a recuperar')
    
    # Comando: info
    subparsers.add_parser('info', help='Obter informações sobre o modelo')
    
    # Comando: config
    config_parser = subparsers.add_parser('config', help='Configurar o sistema')
    config_parser.add_argument('--prompt', type=str, help='Atualizar o prompt de sistema')
    config_parser.add_argument('--show', action='store_true', help='Mostrar configuração atual')
    
    # Comando: list
    list_parser = subparsers.add_parser('list', help='Listar documentos importados')
    list_parser.add_argument('--category', type=str, help='Filtrar por categoria')
    
    return parser

def format_response(response_data: Dict) -> str:
    """
    Formata a resposta para exibição no terminal.
    
    Args:
        response_data: Dados da resposta
        
    Returns:
        Texto formatado
    """
    output = []
    
    # Adicionar resposta
    output.append(f"\n{response_data['response']}\n")
    
    # Adicionar fontes
    if response_data.get('sources'):
        output.append("\nFontes:")
        for i, source in enumerate(response_data['sources']):
            source_text = f"[{i+1}] "
            if source.get('title'):
                source_text += f"\"{source['title']}\""
                if source.get('author'):
                    source_text += f" por {source['author']}"
            elif source.get('path'):
                source_text += os.path.basename(source['path'])
            
            output.append(source_text)
    
    return "\n".join(output)

def handle_import_command(ai, args) -> None:
    """
    Manipula o comando de importação.
    
    Args:
        ai: Instância da IA treinável
        args: Argumentos de linha de comando
    """
    # Preparar metadados
    metadata = {}
    if args.title:
        metadata['title'] = args.title
    if args.author:
        metadata['author'] = args.author
    if args.category:
        metadata['category'] = args.category
    
    # Importar arquivo ou diretório
    if args.file:
        print(f"Importando arquivo: {args.file}")
        result = ai.import_and_process_file(args.file, metadata)
        
        if result['status'] == 'success':
            print(f"Arquivo importado com sucesso. ID do documento: {result['doc_id']}")
            print(f"Palavras-chave: {result['info'].get('processed_data', {}).get('keywords', [])}")
        else:
            print(f"Erro ao importar arquivo: {result.get('message', 'Erro desconhecido')}")
    
    elif args.dir:
        print(f"Importando diretório: {args.dir}")
        result = ai.import_and_process_directory(args.dir, metadata, args.recursive)
        
        if result['status'] == 'success':
            print(f"Diretório importado com sucesso. {result['doc_count']} documentos processados.")
            print(f"IDs dos documentos: {result['doc_ids']}")
        else:
            print(f"Erro ao importar diretório: {result.get('message', 'Erro desconhecido')}")

def handle_train_command(ai, args) -> None:
    """
    Manipula o comando de treinamento.
    
    Args:
        ai: Instância da IA treinável
        args: Argumentos de linha de comando
    """
    print("Iniciando treinamento do modelo...")
    
    # Treinar com documentos específicos ou todos
    docs = args.docs if args.docs else None
    result = ai.train_model(docs)
    
    # Mostrar resultado do treinamento de embeddings
    embedding_result = result.get('embedding_training', {})
    if embedding_result.get('status') == 'success':
        print(f"Treinamento de embeddings concluído com sucesso.")
        print(f"Índice criado: {embedding_result.get('index_name')}")
        print(f"Documentos processados: {embedding_result.get('document_count')}")
    else:
        print(f"Erro no treinamento de embeddings: {embedding_result.get('message', 'Erro desconhecido')}")
    
    # Mostrar resultado do fine-tuning
    fine_tuning_result = result.get('fine_tuning', {})
    if fine_tuning_result.get('status') == 'submitted':
        print(f"Job de fine-tuning iniciado: {fine_tuning_result.get('job_id')}")
        print(f"Exemplos de treinamento: {fine_tuning_result.get('example_count')}")
    elif fine_tuning_result.get('status') == 'skipped':
        print("Fine-tuning não executado (desabilitado nas configurações)")
    else:
        print(f"Erro no fine-tuning: {fine_tuning_result.get('message', 'Erro desconhecido')}")

def handle_ask_command(ai, args) -> None:
    """
    Manipula o comando de pergunta.
    
    Args:
        ai: Instância da IA treinável
        args: Argumentos de linha de comando
    """
    print(f"Pergunta: {args.question}")
    print("Processando...")
    
    # Fazer pergunta com ou sem contexto
    if args.context:
        response_data = ai.answer_with_context(args.question, args.top_k)
    else:
        response_data = ai.answer_question(args.question, args.top_k)
    
    # Formatar e mostrar resposta
    formatted_response = format_response(response_data)
    print(formatted_response)

def handle_info_command(ai, args) -> None:
    """
    Manipula o comando de informação.
    
    Args:
        ai: Instância da IA treinável
        args: Argumentos de linha de comando
    """
    info = ai.get_model_info()
    
    print("\nInformações do Modelo:")
    print(f"Modelo de embeddings: {info['models']['embedding_model']}")
    print(f"Modelo de linguagem: {info['models']['language_model']}")
    print(f"Índice atual: {info['models']['current_index']}")
    print(f"Fine-tuning habilitado: {info['models']['fine_tuning_enabled']}")
    print(f"Documentos processados: {info['document_count']}")
    print(f"Total de treinamentos: {info['total_trainings']}")
    
    if info['training_history']:
        print("\nÚltimos treinamentos:")
        for i, training in enumerate(info['training_history']):
            print(f"  {i+1}. Tipo: {training.get('type')}")
            print(f"     Data: {training.get('timestamp')}")
            if training.get('type') == 'embedding':
                print(f"     Índice: {training.get('index_name')}")
                print(f"     Documentos: {len(training.get('documents', []))}")
            elif training.get('type') == 'fine_tuning':
                print(f"     Status: {training.get('status')}")
                print(f"     Job ID: {training.get('job_id')}")
            print()

def handle_config_command(ai, args) -> None:
    """
    Manipula o comando de configuração.
    
    Args:
        ai: Instância da IA treinável
        args: Argumentos de linha de comando
    """
    if args.prompt:
        # Atualizar prompt de sistema
        result = ai.update_system_prompt(args.prompt)
        if result['status'] == 'success':
            print("Prompt de sistema atualizado com sucesso.")
        else:
            print(f"Erro ao atualizar prompt: {result.get('message', 'Erro desconhecido')}")
    
    if args.show or not args.prompt:
        # Mostrar configuração atual
        info = ai.get_model_info()
        print("\nConfiguração atual:")
        print(f"Modelo de embeddings: {info['models']['embedding_model']}")
        print(f"Modelo de linguagem: {info['models']['language_model']}")
        print(f"Fine-tuning habilitado: {info['models']['fine_tuning_enabled']}")
        print("\nPrompt de sistema:")
        print(f"{info['models']['system_prompt']}")

def handle_list_command(ai, args) -> None:
    """
    Manipula o comando de listagem.
    
    Args:
        ai: Instância da IA treinável
        args: Argumentos de linha de comando
    """
    # Filtrar por categoria se especificado
    filter_by = {"category": args.category} if args.category else None
    
    # Listar documentos
    try:
        documents = ai.data_pipeline.list_documents(filter_by)
        
        if not documents:
            print("Nenhum documento encontrado.")
            return
        
        print(f"\nDocumentos ({len(documents)}):")
        for i, doc in enumerate(documents):
            print(f"{i+1}. ID: {doc['id']}")
            if doc.get('title'):
                print(f"   Título: {doc['title']}")
            if doc.get('author'):
                print(f"   Autor: {doc['author']}")
            if doc.get('category'):
                print(f"   Categoria: {doc['category']}")
            if doc.get('format'):
                print(f"   Formato: {doc['format']}")
            print()
    except Exception as e:
        print(f"Erro ao listar documentos: {e}")

def main():
    """Função principal da interface de linha de comando."""
    # Configurar parser de argumentos
    parser = setup_argparse()
    args = parser.parse_args()
    
    # Se nenhum comando foi especificado, mostrar ajuda
    if not args.command:
        parser.print_help()
        return
    
    try:
        # Criar pipeline de dados
        pipeline = create_pipeline()
        
        # Criar IA treinável
        ai = create_trainable_ai(pipeline)
        
        # Executar comando apropriado
        if args.command == 'import':
            handle_import_command(ai, args)
        elif args.command == 'train':
            handle_train_command(ai, args)
        elif args.command == 'ask':
            handle_ask_command(ai, args)
        elif args.command == 'info':
            handle_info_command(ai, args)
        elif args.command == 'config':
            handle_config_command(ai, args)
        elif args.command == 'list':
            handle_list_command(ai, args)
    except Exception as e:
        logger.error(f"Erro ao executar comando: {e}")
        print(f"Erro: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    sys.exit(main())
