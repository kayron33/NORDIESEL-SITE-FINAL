#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo de importação de dados para a IA treinável.
Responsável por importar textos de diferentes formatos.
"""

import os
import re
import json
import logging
from typing import Dict, List, Optional, Tuple, Any, Union
from pathlib import Path
import shutil

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('importer')

class DataImporter:
    """Classe para importação de dados de diferentes formatos."""
    
    def __init__(self, raw_data_dir: str, metadata_file: str = None):
        """
        Inicializa o importador de dados.
        
        Args:
            raw_data_dir: Diretório para armazenar os dados brutos
            metadata_file: Arquivo para armazenar metadados (opcional)
        """
        self.raw_data_dir = Path(raw_data_dir)
        self.raw_data_dir.mkdir(parents=True, exist_ok=True)
        
        self.metadata_file = metadata_file
        if metadata_file:
            self.metadata_path = Path(metadata_file)
            self.metadata = self._load_metadata()
        else:
            self.metadata_path = self.raw_data_dir / "metadata.json"
            self.metadata = self._load_metadata()
    
    def _load_metadata(self) -> Dict:
        """
        Carrega os metadados existentes ou cria um novo dicionário.
        
        Returns:
            Dicionário de metadados
        """
        if self.metadata_path.exists():
            try:
                with open(self.metadata_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                logger.warning(f"Erro ao carregar metadados de {self.metadata_path}. Criando novo arquivo.")
                return {"documents": {}}
        else:
            return {"documents": {}}
    
    def _save_metadata(self) -> None:
        """Salva os metadados no arquivo."""
        with open(self.metadata_path, 'w', encoding='utf-8') as f:
            json.dump(self.metadata, f, ensure_ascii=False, indent=2)
        logger.info(f"Metadados salvos em {self.metadata_path}")
    
    def import_text_file(self, file_path: str, metadata: Dict = None) -> str:
        """
        Importa um arquivo de texto.
        
        Args:
            file_path: Caminho para o arquivo de texto
            metadata: Metadados associados ao arquivo (opcional)
            
        Returns:
            ID do documento importado
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")
        
        # Gerar ID único para o documento
        doc_id = f"doc_{len(self.metadata['documents']) + 1}"
        
        # Criar diretório para o documento se não existir
        doc_dir = self.raw_data_dir / doc_id
        doc_dir.mkdir(exist_ok=True)
        
        # Copiar arquivo para o diretório de dados brutos
        dest_file = doc_dir / file_path.name
        shutil.copy2(file_path, dest_file)
        
        # Extrair texto do arquivo
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
        except UnicodeDecodeError:
            # Tentar com outra codificação se utf-8 falhar
            try:
                with open(file_path, 'r', encoding='latin-1') as f:
                    text = f.read()
            except Exception as e:
                logger.error(f"Erro ao ler arquivo {file_path}: {e}")
                raise
        
        # Salvar texto extraído
        text_file = doc_dir / "content.txt"
        with open(text_file, 'w', encoding='utf-8') as f:
            f.write(text)
        
        # Preparar metadados
        doc_metadata = {
            "original_file": str(file_path),
            "imported_file": str(dest_file),
            "content_file": str(text_file),
            "format": "text",
            "size_bytes": os.path.getsize(file_path),
            "imported_at": str(Path(file_path).stat().st_mtime),
        }
        
        # Adicionar metadados personalizados
        if metadata:
            doc_metadata.update(metadata)
        
        # Atualizar metadados globais
        self.metadata["documents"][doc_id] = doc_metadata
        self._save_metadata()
        
        logger.info(f"Arquivo de texto importado com sucesso: {file_path} -> {doc_id}")
        return doc_id
    
    def import_pdf_file(self, file_path: str, metadata: Dict = None) -> str:
        """
        Importa um arquivo PDF.
        
        Args:
            file_path: Caminho para o arquivo PDF
            metadata: Metadados associados ao arquivo (opcional)
            
        Returns:
            ID do documento importado
        """
        try:
            import PyPDF2
        except ImportError:
            logger.error("PyPDF2 não está instalado. Instale com: pip install PyPDF2")
            raise
        
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")
        
        # Gerar ID único para o documento
        doc_id = f"doc_{len(self.metadata['documents']) + 1}"
        
        # Criar diretório para o documento se não existir
        doc_dir = self.raw_data_dir / doc_id
        doc_dir.mkdir(exist_ok=True)
        
        # Copiar arquivo para o diretório de dados brutos
        dest_file = doc_dir / file_path.name
        shutil.copy2(file_path, dest_file)
        
        # Extrair texto do PDF
        text = ""
        try:
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                num_pages = len(pdf_reader.pages)
                
                for page_num in range(num_pages):
                    page = pdf_reader.pages[page_num]
                    text += page.extract_text() + "\n\n"
        except Exception as e:
            logger.error(f"Erro ao extrair texto do PDF {file_path}: {e}")
            raise
        
        # Salvar texto extraído
        text_file = doc_dir / "content.txt"
        with open(text_file, 'w', encoding='utf-8') as f:
            f.write(text)
        
        # Preparar metadados
        doc_metadata = {
            "original_file": str(file_path),
            "imported_file": str(dest_file),
            "content_file": str(text_file),
            "format": "pdf",
            "pages": num_pages,
            "size_bytes": os.path.getsize(file_path),
            "imported_at": str(Path(file_path).stat().st_mtime),
        }
        
        # Adicionar metadados personalizados
        if metadata:
            doc_metadata.update(metadata)
        
        # Atualizar metadados globais
        self.metadata["documents"][doc_id] = doc_metadata
        self._save_metadata()
        
        logger.info(f"Arquivo PDF importado com sucesso: {file_path} -> {doc_id}")
        return doc_id
    
    def import_docx_file(self, file_path: str, metadata: Dict = None) -> str:
        """
        Importa um arquivo DOCX.
        
        Args:
            file_path: Caminho para o arquivo DOCX
            metadata: Metadados associados ao arquivo (opcional)
            
        Returns:
            ID do documento importado
        """
        try:
            import docx
        except ImportError:
            logger.error("python-docx não está instalado. Instale com: pip install python-docx")
            raise
        
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")
        
        # Gerar ID único para o documento
        doc_id = f"doc_{len(self.metadata['documents']) + 1}"
        
        # Criar diretório para o documento se não existir
        doc_dir = self.raw_data_dir / doc_id
        doc_dir.mkdir(exist_ok=True)
        
        # Copiar arquivo para o diretório de dados brutos
        dest_file = doc_dir / file_path.name
        shutil.copy2(file_path, dest_file)
        
        # Extrair texto do DOCX
        text = ""
        try:
            doc = docx.Document(file_path)
            for para in doc.paragraphs:
                text += para.text + "\n"
        except Exception as e:
            logger.error(f"Erro ao extrair texto do DOCX {file_path}: {e}")
            raise
        
        # Salvar texto extraído
        text_file = doc_dir / "content.txt"
        with open(text_file, 'w', encoding='utf-8') as f:
            f.write(text)
        
        # Preparar metadados
        doc_metadata = {
            "original_file": str(file_path),
            "imported_file": str(dest_file),
            "content_file": str(text_file),
            "format": "docx",
            "size_bytes": os.path.getsize(file_path),
            "imported_at": str(Path(file_path).stat().st_mtime),
        }
        
        # Adicionar metadados personalizados
        if metadata:
            doc_metadata.update(metadata)
        
        # Atualizar metadados globais
        self.metadata["documents"][doc_id] = doc_metadata
        self._save_metadata()
        
        logger.info(f"Arquivo DOCX importado com sucesso: {file_path} -> {doc_id}")
        return doc_id
    
    def import_file(self, file_path: str, metadata: Dict = None) -> str:
        """
        Importa um arquivo detectando automaticamente o formato.
        
        Args:
            file_path: Caminho para o arquivo
            metadata: Metadados associados ao arquivo (opcional)
            
        Returns:
            ID do documento importado
        """
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"Arquivo não encontrado: {file_path}")
        
        # Detectar formato pelo sufixo
        suffix = file_path.suffix.lower()
        
        if suffix == '.txt':
            return self.import_text_file(file_path, metadata)
        elif suffix == '.pdf':
            return self.import_pdf_file(file_path, metadata)
        elif suffix == '.docx':
            return self.import_docx_file(file_path, metadata)
        else:
            logger.warning(f"Formato não suportado: {suffix}. Tentando importar como texto.")
            return self.import_text_file(file_path, metadata)
    
    def import_directory(self, dir_path: str, metadata_template: Dict = None, 
                         recursive: bool = False) -> List[str]:
        """
        Importa todos os arquivos de um diretório.
        
        Args:
            dir_path: Caminho para o diretório
            metadata_template: Modelo de metadados para todos os arquivos (opcional)
            recursive: Se deve importar arquivos em subdiretórios
            
        Returns:
            Lista de IDs dos documentos importados
        """
        dir_path = Path(dir_path)
        if not dir_path.exists() or not dir_path.is_dir():
            raise NotADirectoryError(f"Diretório não encontrado: {dir_path}")
        
        imported_ids = []
        
        # Função para processar um arquivo
        def process_file(file_path):
            try:
                # Criar metadados específicos para o arquivo
                file_metadata = metadata_template.copy() if metadata_template else {}
                file_metadata["source_directory"] = str(dir_path)
                
                # Importar arquivo
                doc_id = self.import_file(file_path, file_metadata)
                imported_ids.append(doc_id)
            except Exception as e:
                logger.error(f"Erro ao importar {file_path}: {e}")
        
        # Percorrer arquivos no diretório
        if recursive:
            for root, _, files in os.walk(dir_path):
                for file in files:
                    file_path = Path(root) / file
                    if file_path.suffix.lower() in ['.txt', '.pdf', '.docx']:
                        process_file(file_path)
        else:
            for file_path in dir_path.iterdir():
                if file_path.is_file() and file_path.suffix.lower() in ['.txt', '.pdf', '.docx']:
                    process_file(file_path)
        
        logger.info(f"Importados {len(imported_ids)} arquivos do diretório {dir_path}")
        return imported_ids
    
    def get_document_content(self, doc_id: str) -> str:
        """
        Obtém o conteúdo de um documento importado.
        
        Args:
            doc_id: ID do documento
            
        Returns:
            Texto do documento
        """
        if doc_id not in self.metadata["documents"]:
            raise ValueError(f"Documento não encontrado: {doc_id}")
        
        content_file = self.metadata["documents"][doc_id]["content_file"]
        try:
            with open(content_file, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            logger.error(f"Erro ao ler conteúdo do documento {doc_id}: {e}")
            raise
    
    def get_document_metadata(self, doc_id: str) -> Dict:
        """
        Obtém os metadados de um documento importado.
        
        Args:
            doc_id: ID do documento
            
        Returns:
            Metadados do documento
        """
        if doc_id not in self.metadata["documents"]:
            raise ValueError(f"Documento não encontrado: {doc_id}")
        
        return self.metadata["documents"][doc_id]
    
    def update_document_metadata(self, doc_id: str, metadata: Dict) -> None:
        """
        Atualiza os metadados de um documento.
        
        Args:
            doc_id: ID do documento
            metadata: Novos metadados (serão mesclados com os existentes)
        """
        if doc_id not in self.metadata["documents"]:
            raise ValueError(f"Documento não encontrado: {doc_id}")
        
        self.metadata["documents"][doc_id].update(metadata)
        self._save_metadata()
        logger.info(f"Metadados do documento {doc_id} atualizados")
    
    def list_documents(self, filter_by: Dict = None) -> List[Dict]:
        """
        Lista todos os documentos importados, opcionalmente filtrados.
        
        Args:
            filter_by: Dicionário de filtros (opcional)
            
        Returns:
            Lista de documentos com seus metadados
        """
        documents = []
        
        for doc_id, metadata in self.metadata["documents"].items():
            # Se não há filtro, incluir todos os documentos
            if not filter_by:
                doc_info = metadata.copy()
                doc_info["id"] = doc_id
                documents.append(doc_info)
                continue
            
            # Verificar se o documento atende a todos os critérios de filtro
            match = True
            for key, value in filter_by.items():
                if key not in metadata or metadata[key] != value:
                    match = False
                    break
            
            if match:
                doc_info = metadata.copy()
                doc_info["id"] = doc_id
                documents.append(doc_info)
        
        return documents
    
    def delete_document(self, doc_id: str) -> bool:
        """
        Remove um documento importado.
        
        Args:
            doc_id: ID do documento
            
        Returns:
            True se removido com sucesso
        """
        if doc_id not in self.metadata["documents"]:
            logger.warning(f"Documento não encontrado para exclusão: {doc_id}")
            return False
        
        # Remover diretório do documento
        doc_dir = self.raw_data_dir / doc_id
        if doc_dir.exists():
            shutil.rmtree(doc_dir)
        
        # Remover dos metadados
        del self.metadata["documents"][doc_id]
        self._save_metadata()
        
        logger.info(f"Documento {doc_id} removido com sucesso")
        return True


# Função de conveniência para criar um importador com configuração padrão
def create_importer(base_dir: str = None) -> DataImporter:
    """
    Cria um importador de dados com configuração padrão.
    
    Args:
        base_dir: Diretório base para armazenar dados (opcional)
        
    Returns:
        Instância de DataImporter
    """
    if not base_dir:
        base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data')
    
    raw_data_dir = os.path.join(base_dir, 'raw')
    metadata_file = os.path.join(base_dir, 'metadata.json')
    
    return DataImporter(raw_data_dir, metadata_file)


# Exemplo de uso
if __name__ == "__main__":
    # Criar importador
    importer = create_importer()
    
    # Importar um arquivo de texto
    doc_id = importer.import_text_file("exemplo.txt", {"title": "Exemplo", "author": "Autor"})
    
    # Obter conteúdo do documento
    content = importer.get_document_content(doc_id)
    print(f"Conteúdo do documento {doc_id}:\n{content[:100]}...")
    
    # Listar documentos
    documents = importer.list_documents()
    print(f"Total de documentos: {len(documents)}")
