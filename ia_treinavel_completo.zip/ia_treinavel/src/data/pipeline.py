#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo principal para processamento de dados da IA treinável.
Integra os módulos de importação, processamento e embeddings.
"""

import os
import json
import logging
from typing import Dict, List, Optional, Tuple, Any, Union
from pathlib import Path

# Importar módulos locais
from .importer import DataImporter, create_importer
from .processor import TextProcessor, create_processor
from .embedder import TextEmbedder, create_embedder

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('data_pipeline')

class DataPipeline:
    """Classe para orquestrar o pipeline completo de processamento de dados."""
    
    def __init__(self, base_dir: str = None, embedding_model: str = 'all-MiniLM-L6-v2'):
        """
        Inicializa o pipeline de dados.
        
        Args:
            base_dir: Diretório base para armazenar dados (opcional)
            embedding_model: Nome do modelo de embedding (opcional)
        """
        if not base_dir:
            base_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data')
        
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        
        # Inicializar componentes
        self.importer = create_importer(base_dir)
        self.processor = create_processor(base_dir)
        self.embedder = create_embedder(base_dir, embedding_model)
        
        # Criar arquivo de controle do pipeline
        self.pipeline_file = self.base_dir / "pipeline_status.json"
        self.pipeline_status = self._load_pipeline_status()
    
    def _load_pipeline_status(self) -> Dict:
        """
        Carrega o status do pipeline ou cria um novo.
        
        Returns:
            Dicionário com status do pipeline
        """
        if self.pipeline_file.exists():
            try:
                with open(self.pipeline_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except json.JSONDecodeError:
                logger.warning(f"Erro ao carregar status do pipeline. Criando novo arquivo.")
                return {"documents": {}}
        else:
            return {"documents": {}}
    
    def _save_pipeline_status(self) -> None:
        """Salva o status do pipeline no arquivo."""
        with open(self.pipeline_file, 'w', encoding='utf-8') as f:
            json.dump(self.pipeline_status, f, ensure_ascii=False, indent=2)
        logger.info(f"Status do pipeline salvo em {self.pipeline_file}")
    
    def process_file(self, file_path: str, metadata: Dict = None) -> str:
        """
        Processa um arquivo completo através do pipeline.
        
        Args:
            file_path: Caminho para o arquivo
            metadata: Metadados associados ao arquivo (opcional)
            
        Returns:
            ID do documento processado
        """
        # 1. Importar arquivo
        logger.info(f"Iniciando processamento do arquivo: {file_path}")
        doc_id = self.importer.import_file(file_path, metadata)
        
        # 2. Obter conteúdo do documento
        text = self.importer.get_document_content(doc_id)
        doc_metadata = self.importer.get_document_metadata(doc_id)
        
        # 3. Processar texto
        processed_data = self.processor.process_document(doc_id, text, doc_metadata)
        
        # 4. Gerar embeddings
        segments = self.processor.get_document_segments(doc_id)
        embedding_metadata = self.embedder.process_document(doc_id, segments)
        
        # 5. Atualizar status do pipeline
        self.pipeline_status["documents"][doc_id] = {
            "file_path": file_path,
            "status": "processed",
            "metadata": doc_metadata,
            "processed_data": {
                "segment_count": processed_data["segment_count"],
                "keywords": processed_data["keywords"]
            },
            "embedding_data": {
                "model": embedding_metadata["model_name"],
                "segment_count": embedding_metadata["segment_count"]
            }
        }
        self._save_pipeline_status()
        
        logger.info(f"Arquivo processado com sucesso: {file_path} -> {doc_id}")
        return doc_id
    
    def process_directory(self, dir_path: str, metadata_template: Dict = None, 
                          recursive: bool = False) -> List[str]:
        """
        Processa todos os arquivos de um diretório.
        
        Args:
            dir_path: Caminho para o diretório
            metadata_template: Modelo de metadados para todos os arquivos (opcional)
            recursive: Se deve processar arquivos em subdiretórios
            
        Returns:
            Lista de IDs dos documentos processados
        """
        # 1. Importar arquivos do diretório
        doc_ids = self.importer.import_directory(dir_path, metadata_template, recursive)
        
        # 2. Processar cada documento
        processed_ids = []
        for doc_id in doc_ids:
            try:
                # Obter metadados e conteúdo
                doc_metadata = self.importer.get_document_metadata(doc_id)
                text = self.importer.get_document_content(doc_id)
                
                # Processar texto
                processed_data = self.processor.process_document(doc_id, text, doc_metadata)
                
                # Gerar embeddings
                segments = self.processor.get_document_segments(doc_id)
                embedding_metadata = self.embedder.process_document(doc_id, segments)
                
                # Atualizar status do pipeline
                self.pipeline_status["documents"][doc_id] = {
                    "file_path": doc_metadata["original_file"],
                    "status": "processed",
                    "metadata": doc_metadata,
                    "processed_data": {
                        "segment_count": processed_data["segment_count"],
                        "keywords": processed_data["keywords"]
                    },
                    "embedding_data": {
                        "model": embedding_metadata["model_name"],
                        "segment_count": embedding_metadata["segment_count"]
                    }
                }
                
                processed_ids.append(doc_id)
                logger.info(f"Documento {doc_id} processado com sucesso")
            except Exception as e:
                logger.error(f"Erro ao processar documento {doc_id}: {e}")
                self.pipeline_status["documents"][doc_id] = {
                    "status": "error",
                    "error": str(e)
                }
        
        # Salvar status do pipeline
        self._save_pipeline_status()
        
        logger.info(f"Processados {len(processed_ids)} documentos do diretório {dir_path}")
        return processed_ids
    
    def build_search_index(self, index_name: str = "corpus_index") -> str:
        """
        Constrói um índice de busca para todos os documentos processados.
        
        Args:
            index_name: Nome do índice
            
        Returns:
            Caminho do diretório do índice
        """
        # 1. Coletar embeddings de todos os documentos
        embeddings_list = []
        
        for doc_id in self.pipeline_status["documents"]:
            if self.pipeline_status["documents"][doc_id].get("status") == "processed":
                try:
                    doc_embeddings = self.embedder.load_embeddings(doc_id)
                    embeddings_list.append(doc_embeddings)
                except Exception as e:
                    logger.error(f"Erro ao carregar embeddings do documento {doc_id}: {e}")
        
        if not embeddings_list:
            logger.warning("Nenhum embedding encontrado para construir índice")
            return None
        
        # 2. Criar índice FAISS
        index, id_mapping = self.embedder.create_faiss_index(embeddings_list)
        
        # 3. Salvar índice
        index_dir = self.embedder.save_faiss_index(index, id_mapping, index_name)
        
        # 4. Atualizar status do pipeline
        self.pipeline_status["indices"] = self.pipeline_status.get("indices", {})
        self.pipeline_status["indices"][index_name] = {
            "path": index_dir,
            "document_count": len(embeddings_list),
            "vector_count": len(id_mapping)
        }
        self._save_pipeline_status()
        
        logger.info(f"Índice de busca construído com sucesso: {index_name}")
        return index_dir
    
    def search(self, query: str, top_k: int = 5, index_name: str = "corpus_index") -> List[Dict]:
        """
        Busca segmentos relevantes para uma consulta.
        
        Args:
            query: Texto da consulta
            top_k: Número de resultados a retornar
            index_name: Nome do índice a ser usado
            
        Returns:
            Lista de resultados com segmentos e metadados
        """
        # 1. Carregar índice FAISS
        try:
            index, id_mapping = self.embedder.load_faiss_index(index_name)
        except FileNotFoundError:
            logger.warning(f"Índice {index_name} não encontrado. Construindo novo índice.")
            self.build_search_index(index_name)
            index, id_mapping = self.embedder.load_faiss_index(index_name)
        
        # 2. Buscar segmentos similares
        similar_segments = self.embedder.search_similar(query, index, id_mapping, top_k)
        
        # 3. Enriquecer resultados com conteúdo e metadados
        results = []
        
        for item in similar_segments:
            segment_id = item["segment_id"]
            doc_id, seg_num = segment_id.split("_seg_")
            seg_num = int(seg_num)
            
            try:
                # Obter segmentos do documento
                segments = self.processor.get_document_segments(doc_id)
                segment_text = segments[seg_num] if seg_num < len(segments) else ""
                
                # Obter metadados do documento
                doc_metadata = self.importer.get_document_metadata(doc_id)
                
                # Adicionar ao resultado
                result = {
                    "segment_id": segment_id,
                    "doc_id": doc_id,
                    "similarity": item["similarity"],
                    "text": segment_text,
                    "metadata": {
                        "title": doc_metadata.get("title", ""),
                        "author": doc_metadata.get("author", ""),
                        "format": doc_metadata.get("format", ""),
                        "source": doc_metadata.get("original_file", "")
                    }
                }
                
                results.append(result)
            except Exception as e:
                logger.error(f"Erro ao obter dados para o segmento {segment_id}: {e}")
        
        logger.info(f"Busca por '{query}' retornou {len(results)} resultados")
        return results
    
    def get_document_info(self, doc_id: str) -> Dict:
        """
        Obtém informações completas sobre um documento.
        
        Args:
            doc_id: ID do documento
            
        Returns:
            Dicionário com informações do documento
        """
        if doc_id not in self.pipeline_status["documents"]:
            raise ValueError(f"Documento não encontrado: {doc_id}")
        
        # Obter informações básicas do pipeline
        doc_info = self.pipeline_status["documents"][doc_id].copy()
        
        try:
            # Adicionar metadados do documento
            doc_metadata = self.importer.get_document_metadata(doc_id)
            doc_info["metadata"] = doc_metadata
            
            # Adicionar dados processados
            processed_data = self.processor.get_processed_document(doc_id)
            doc_info["processed_data"] = {
                "keywords": processed_data["keywords"],
                "entities": processed_data["entities"],
                "segment_count": processed_data["segment_count"],
                "char_count": processed_data["char_count"],
                "word_count": processed_data["word_count"]
            }
            
            # Adicionar metadados de embeddings
            embedding_metadata = self.embedder.get_embedding_metadata(doc_id)
            doc_info["embedding_data"] = embedding_metadata
        except Exception as e:
            logger.error(f"Erro ao obter informações completas do documento {doc_id}: {e}")
            doc_info["error"] = str(e)
        
        return doc_info
    
    def list_processed_documents(self) -> List[Dict]:
        """
        Lista todos os documentos processados.
        
        Returns:
            Lista de documentos com informações básicas
        """
        documents = []
        
        for doc_id, info in self.pipeline_status["documents"].items():
            if info.get("status") == "processed":
                doc_info = {
                    "id": doc_id,
                    "file_path": info.get("file_path", ""),
                    "title": info.get("metadata", {}).get("title", ""),
                    "author": info.get("metadata", {}).get("author", ""),
                    "format": info.get("metadata", {}).get("format", ""),
                    "segment_count": info.get("processed_data", {}).get("segment_count", 0),
                    "keywords": info.get("processed_data", {}).get("keywords", [])
                }
                documents.append(doc_info)
        
        return documents


# Função de conveniência para criar um pipeline com configuração padrão
def create_pipeline(base_dir: str = None, embedding_model: str = 'all-MiniLM-L6-v2') -> DataPipeline:
    """
    Cria um pipeline de dados com configuração padrão.
    
    Args:
        base_dir: Diretório base para armazenar dados (opcional)
        embedding_model: Nome do modelo de embedding (opcional)
        
    Returns:
        Instância de DataPipeline
    """
    return DataPipeline(base_dir, embedding_model)


# Exemplo de uso
if __name__ == "__main__":
    # Criar pipeline
    pipeline = create_pipeline()
    
    # Processar um arquivo
    doc_id = pipeline.process_file("exemplo.txt", {"title": "Exemplo", "author": "Autor"})
    
    # Construir índice de busca
    pipeline.build_search_index()
    
    # Buscar informações
    results = pipeline.search("investimento em ações")
    
    for result in results:
        print(f"Documento: {result['metadata']['title']}")
        print(f"Similaridade: {result['similarity']:.4f}")
        print(f"Texto: {result['text'][:100]}...")
        print("-" * 50)
