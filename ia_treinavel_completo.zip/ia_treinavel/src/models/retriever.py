#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Módulo de recuperação de informações para a IA treinável.
Responsável por buscar informações relevantes para consultas.
"""

import os
import json
import logging
from typing import Dict, List, Optional, Tuple, Any, Union
from pathlib import Path

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('retriever')

class InformationRetriever:
    """Classe para recuperação de informações relevantes para consultas."""
    
    def __init__(self, data_pipeline, index_name: str = "corpus_index"):
        """
        Inicializa o recuperador de informações.
        
        Args:
            data_pipeline: Pipeline de dados para acesso aos documentos e embeddings
            index_name: Nome do índice a ser usado para busca
        """
        self.pipeline = data_pipeline
        self.index_name = index_name
    
    def retrieve(self, query: str, top_k: int = 5) -> List[Dict]:
        """
        Recupera informações relevantes para uma consulta.
        
        Args:
            query: Texto da consulta
            top_k: Número de resultados a retornar
            
        Returns:
            Lista de resultados com segmentos e metadados
        """
        # Buscar segmentos relevantes usando o pipeline
        results = self.pipeline.search(query, top_k, self.index_name)
        
        # Enriquecer resultados com informações adicionais se necessário
        for result in results:
            # Adicionar fonte formatada
            metadata = result.get("metadata", {})
            source = ""
            
            if metadata.get("title"):
                source += f'"{metadata["title"]}"'
                
                if metadata.get("author"):
                    source += f' por {metadata["author"]}'
            elif metadata.get("source"):
                source = metadata["source"]
            
            result["formatted_source"] = source
        
        logger.info(f"Recuperados {len(results)} segmentos relevantes para a consulta: '{query}'")
        return results
    
    def retrieve_with_context(self, query: str, top_k: int = 5, context_size: int = 1) -> List[Dict]:
        """
        Recupera informações relevantes com contexto adicional.
        
        Args:
            query: Texto da consulta
            top_k: Número de resultados principais a retornar
            context_size: Número de segmentos de contexto antes/depois a incluir
            
        Returns:
            Lista de resultados com segmentos, contexto e metadados
        """
        # Buscar segmentos relevantes
        results = self.retrieve(query, top_k)
        
        # Adicionar contexto para cada resultado
        for result in results:
            segment_id = result["segment_id"]
            doc_id, seg_num = segment_id.split("_seg_")
            seg_num = int(seg_num)
            
            try:
                # Obter todos os segmentos do documento
                segments = self.pipeline.processor.get_document_segments(doc_id)
                
                # Determinar intervalo de contexto
                start_idx = max(0, seg_num - context_size)
                end_idx = min(len(segments), seg_num + context_size + 1)
                
                # Extrair segmentos de contexto
                context_before = segments[start_idx:seg_num]
                context_after = segments[seg_num+1:end_idx]
                
                # Adicionar ao resultado
                result["context_before"] = context_before
                result["context_after"] = context_after
                result["context_full"] = "\n\n".join(context_before + [result["text"]] + context_after)
            except Exception as e:
                logger.error(f"Erro ao obter contexto para o segmento {segment_id}: {e}")
                result["context_before"] = []
                result["context_after"] = []
                result["context_full"] = result["text"]
        
        return results
    
    def retrieve_by_keywords(self, keywords: List[str], top_k: int = 5) -> List[Dict]:
        """
        Recupera informações relevantes baseadas em palavras-chave.
        
        Args:
            keywords: Lista de palavras-chave
            top_k: Número de resultados a retornar
            
        Returns:
            Lista de resultados com segmentos e metadados
        """
        # Construir consulta a partir das palavras-chave
        query = " ".join(keywords)
        
        # Buscar segmentos relevantes
        return self.retrieve(query, top_k)
    
    def retrieve_multiple_queries(self, queries: List[str], top_k_per_query: int = 3) -> List[Dict]:
        """
        Recupera informações para múltiplas consultas e combina os resultados.
        
        Args:
            queries: Lista de consultas
            top_k_per_query: Número de resultados por consulta
            
        Returns:
            Lista combinada de resultados únicos
        """
        all_results = []
        seen_segment_ids = set()
        
        for query in queries:
            results = self.retrieve(query, top_k_per_query)
            
            for result in results:
                segment_id = result["segment_id"]
                if segment_id not in seen_segment_ids:
                    all_results.append(result)
                    seen_segment_ids.add(segment_id)
        
        # Ordenar por similaridade
        all_results.sort(key=lambda x: x["similarity"], reverse=True)
        
        logger.info(f"Recuperados {len(all_results)} segmentos únicos para {len(queries)} consultas")
        return all_results
    
    def format_results_as_context(self, results: List[Dict], max_tokens: int = 2000) -> str:
        """
        Formata os resultados como um contexto para o modelo de linguagem.
        
        Args:
            results: Lista de resultados da recuperação
            max_tokens: Número máximo aproximado de tokens a incluir
            
        Returns:
            Texto formatado com as informações recuperadas
        """
        if not results:
            return "Não foram encontradas informações relevantes."
        
        context_parts = []
        total_chars = 0
        char_limit = max_tokens * 4  # Estimativa aproximada de caracteres por token
        
        for i, result in enumerate(results):
            # Formatar texto com fonte
            text = result["text"]
            source = result.get("formatted_source", "")
            
            formatted_text = f"[{i+1}] {text}"
            if source:
                formatted_text += f" (Fonte: {source})"
            
            # Verificar limite de tamanho
            if total_chars + len(formatted_text) > char_limit:
                break
                
            context_parts.append(formatted_text)
            total_chars += len(formatted_text)
        
        # Juntar todas as partes
        full_context = "\n\n".join(context_parts)
        
        return full_context


# Função de conveniência para criar um recuperador com configuração padrão
def create_retriever(data_pipeline, index_name: str = "corpus_index") -> InformationRetriever:
    """
    Cria um recuperador de informações com configuração padrão.
    
    Args:
        data_pipeline: Pipeline de dados
        index_name: Nome do índice a ser usado
        
    Returns:
        Instância de InformationRetriever
    """
    return InformationRetriever(data_pipeline, index_name)


# Exemplo de uso
if __name__ == "__main__":
    # Importar pipeline
    from pipeline import create_pipeline
    
    # Criar pipeline e recuperador
    pipeline = create_pipeline()
    retriever = create_retriever(pipeline)
    
    # Recuperar informações para uma consulta
    results = retriever.retrieve("estratégias de investimento para iniciantes")
    
    # Mostrar resultados
    for i, result in enumerate(results):
        print(f"Resultado {i+1}:")
        print(f"Texto: {result['text'][:100]}...")
        print(f"Fonte: {result.get('formatted_source', 'N/A')}")
        print(f"Similaridade: {result['similarity']:.4f}")
        print("-" * 50)
