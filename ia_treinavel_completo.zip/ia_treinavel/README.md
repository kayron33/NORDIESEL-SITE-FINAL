# IA Treinável para Livros de Investimento e Riqueza

## Visão Geral

Este projeto implementa uma IA treinável em Python que permite ao usuário alimentar o sistema com seus próprios dados sobre livros de investimento, riqueza e outros temas de interesse. O sistema processa textos de diferentes formatos, cria representações vetoriais do conteúdo e permite consultas em linguagem natural para obter respostas baseadas nos documentos importados.

## Características Principais

- **Importação de Múltiplos Formatos**: Suporte para arquivos TXT, PDF e DOCX
- **Processamento de Texto Avançado**: Tokenização, segmentação e extração de palavras-chave
- **Representação Vetorial**: Criação de embeddings para busca semântica
- **Treinamento Personalizado**: Atualização do modelo com novos documentos
- **Consultas em Linguagem Natural**: Perguntas e respostas baseadas no conteúdo importado
- **Interface Dupla**: Linha de comando (CLI) e interface web amigável
- **Citação de Fontes**: Rastreabilidade das informações nas respostas

## Estrutura do Projeto

```
ia_treinavel/
├── data/               # Diretório para armazenar dados processados
├── models/             # Diretório para armazenar modelos treinados
├── src/                # Código-fonte do projeto
│   ├── data/           # Módulos de processamento de dados
│   │   ├── importer.py # Importação de diferentes formatos de arquivo
│   │   ├── processor.py # Processamento de texto
│   │   ├── embedder.py # Geração de embeddings
│   │   └── pipeline.py # Pipeline integrado de processamento
│   └── models/         # Módulos do modelo de IA
│       ├── retriever.py # Recuperação de informações
│       ├── generator.py # Geração de respostas
│       ├── trainer.py  # Treinamento do modelo
│       └── model.py    # Modelo principal
├── cli.py              # Interface de linha de comando
├── web_app.py          # Aplicação web
├── requirements.txt    # Dependências do projeto
└── test_system.py      # Script de teste do sistema
```

## Requisitos

- Python 3.8 ou superior
- Bibliotecas principais:
  - sentence-transformers (para embeddings)
  - nltk (para processamento de texto)
  - PyPDF2 e python-docx (para importação de arquivos)
  - Flask (para interface web)
  - faiss-cpu (para indexação e busca vetorial)

## Instalação

1. Clone o repositório ou baixe os arquivos
2. Instale as dependências:

```bash
pip install -r requirements.txt
```

3. Baixe os recursos necessários do NLTK:

```bash
python -c "import nltk; nltk.download('punkt'); nltk.download('stopwords')"
```

## Uso

### Interface de Linha de Comando

```bash
# Importar um documento
python cli.py import --file /caminho/para/livro.pdf --title "Nome do Livro" --author "Autor"

# Treinar o modelo
python cli.py train

# Fazer uma pergunta
python cli.py ask "Qual a melhor estratégia de investimento para longo prazo?"

# Listar documentos importados
python cli.py list-docs
```

### Interface Web

```bash
# Iniciar a aplicação web
python web_app.py
```

Acesse http://localhost:5000 no seu navegador para usar a interface gráfica.

## Exemplos de Uso

### Importação de Documentos

```bash
# Importar um livro em PDF
python cli.py import --file "livros/pai_rico_pai_pobre.pdf" --title "Pai Rico, Pai Pobre" --author "Robert Kiyosaki" --category "educação financeira"

# Importar um artigo em DOCX
python cli.py import --file "artigos/investimentos_2023.docx" --title "Panorama de Investimentos 2023" --author "Revista Exame" --category "análise de mercado"

# Importar um diretório inteiro
python cli.py import-dir --dir "meus_livros/" --category "finanças pessoais"
```

### Consultas

```bash
# Perguntas simples
python cli.py ask "O que é independência financeira?"

# Perguntas específicas
python cli.py ask "Quais são as estratégias de Warren Buffett para investir em ações?"

# Comparações
python cli.py ask "Qual a diferença entre investir em ações e fundos imobiliários?"
```

## Personalização

### Configuração do Modelo de Embeddings

O sistema permite escolher diferentes modelos de embeddings:

```bash
# Configurar modelo de embeddings
python cli.py config --embedding-model "all-MiniLM-L6-v2"
```

### Ajuste de Parâmetros de Busca

```bash
# Configurar parâmetros de busca
python cli.py config --top-k 10 --similarity-threshold 0.7
```

## Limitações Atuais

- O processamento de PDFs complexos com muitas imagens pode ser impreciso
- Documentos muito longos são processados em partes, podendo perder contexto entre seções
- O sistema não possui capacidade de raciocínio além do conteúdo dos documentos importados

## Próximos Passos

- Implementação de fine-tuning completo de modelos de linguagem
- Suporte para processamento de imagens e gráficos em documentos
- Melhorias na extração de estrutura de documentos (capítulos, seções)
- Adição de suporte para mais idiomas além do português

## Contribuição

Contribuições são bem-vindas! Sinta-se à vontade para abrir issues ou enviar pull requests com melhorias.

## Licença

Este projeto está licenciado sob a licença MIT - veja o arquivo LICENSE para detalhes.
