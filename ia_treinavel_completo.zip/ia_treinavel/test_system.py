#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Script para testar a IA treinável com dados de investimento.
"""

import os
import sys
import logging
import argparse
from pathlib import Path

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger('tester')

# Adicionar diretório pai ao path para importar módulos
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Importar módulos do projeto
from src.data.pipeline import create_pipeline
from src.models.model import create_trainable_ai

def download_sample_data(output_dir):
    """
    Baixa dados de amostra sobre investimentos.
    
    Args:
        output_dir: Diretório para salvar os dados
    
    Returns:
        Lista de caminhos para os arquivos baixados
    """
    import requests
    from tqdm import tqdm
    
    # Criar diretório se não existir
    os.makedirs(output_dir, exist_ok=True)
    
    # Lista de URLs de livros e artigos sobre investimentos em domínio público
    sources = [
        {
            "url": "https://www.cmvm.pt/pt/EstatisticasEstudosEPublicacoes/Brochuras/Documents/Guia_do_Investidor.pdf",
            "filename": "Guia_do_Investidor.pdf",
            "title": "Guia do Investidor",
            "author": "CMVM",
            "category": "investimentos"
        },
        {
            "url": "https://www.investidor.gov.br/portaldoinvestidor/export/sites/portaldoinvestidor/publicacao/Livro/livro_TOP_CVM_COMPLETO.pdf",
            "filename": "Guia_CVM_Investidor.pdf",
            "title": "Guia CVM do Investidor",
            "author": "CVM Brasil",
            "category": "investimentos"
        }
    ]
    
    downloaded_files = []
    
    for source in sources:
        output_path = os.path.join(output_dir, source["filename"])
        
        # Verificar se o arquivo já existe
        if os.path.exists(output_path):
            logger.info(f"Arquivo já existe: {output_path}")
            downloaded_files.append({
                "path": output_path,
                "metadata": {
                    "title": source.get("title", ""),
                    "author": source.get("author", ""),
                    "category": source.get("category", "")
                }
            })
            continue
        
        try:
            logger.info(f"Baixando {source['url']}...")
            
            # Fazer requisição
            response = requests.get(source["url"], stream=True)
            response.raise_for_status()
            
            # Obter tamanho total
            total_size = int(response.headers.get('content-length', 0))
            
            # Baixar com barra de progresso
            with open(output_path, 'wb') as f, tqdm(
                desc=source["filename"],
                total=total_size,
                unit='B',
                unit_scale=True,
                unit_divisor=1024,
            ) as bar:
                for chunk in response.iter_content(chunk_size=8192):
                    size = f.write(chunk)
                    bar.update(size)
            
            logger.info(f"Download concluído: {output_path}")
            
            downloaded_files.append({
                "path": output_path,
                "metadata": {
                    "title": source.get("title", ""),
                    "author": source.get("author", ""),
                    "category": source.get("category", "")
                }
            })
        except Exception as e:
            logger.error(f"Erro ao baixar {source['url']}: {e}")
    
    return downloaded_files

def create_sample_text_files(output_dir):
    """
    Cria arquivos de texto de amostra sobre investimentos.
    
    Args:
        output_dir: Diretório para salvar os arquivos
        
    Returns:
        Lista de caminhos para os arquivos criados
    """
    # Criar diretório se não existir
    os.makedirs(output_dir, exist_ok=True)
    
    # Conteúdo de amostra sobre investimentos
    samples = [
        {
            "filename": "investimentos_acoes.txt",
            "title": "Investimentos em Ações",
            "author": "Equipe IA Treinável",
            "category": "ações",
            "content": """# Investimentos em Ações: Guia Básico

## Introdução

Investir em ações significa tornar-se sócio de uma empresa de capital aberto, adquirindo uma pequena parte dela. Ao comprar ações, você passa a ser proprietário de uma fração da empresa e tem direito a participar dos seus resultados, sejam eles positivos ou negativos.

## Tipos de Ações

Existem dois tipos principais de ações:

1. **Ações Ordinárias (ON)**: Dão direito a voto nas assembleias de acionistas.
2. **Ações Preferenciais (PN)**: Geralmente não dão direito a voto, mas oferecem preferência na distribuição de dividendos.

## Retornos do Investimento em Ações

O retorno do investimento em ações pode vir de duas formas:

1. **Valorização**: Quando o preço da ação aumenta e você pode vender por um valor maior do que pagou.
2. **Dividendos**: Parte do lucro da empresa que é distribuída aos acionistas periodicamente.

## Estratégias de Investimento

### Buy and Hold (Comprar e Segurar)
Esta estratégia consiste em comprar ações de boas empresas e mantê-las por longos períodos, independentemente das flutuações de curto prazo do mercado. É baseada na ideia de que, no longo prazo, boas empresas tendem a valorizar e gerar retornos consistentes.

### Value Investing (Investimento em Valor)
Popularizada por Benjamin Graham e Warren Buffett, esta estratégia busca identificar ações que estejam sendo negociadas abaixo do seu valor intrínseco. O investidor procura empresas sólidas, com bons fundamentos, mas que estejam temporariamente subvalorizadas pelo mercado.

### Growth Investing (Investimento em Crescimento)
Foca em empresas com alto potencial de crescimento, mesmo que suas ações pareçam caras pelos métodos tradicionais de avaliação. Investidores buscam empresas inovadoras, em setores em expansão, que possam multiplicar seu valor no futuro.

## Riscos do Investimento em Ações

1. **Risco de Mercado**: Flutuações gerais do mercado podem afetar o preço das ações.
2. **Risco Específico**: Problemas particulares da empresa podem desvalorizar suas ações.
3. **Risco de Liquidez**: Dificuldade em vender as ações rapidamente sem afetar seu preço.
4. **Risco Setorial**: Problemas que afetam todo um setor da economia.

## Dicas para Iniciantes

1. **Comece com pouco**: Invista valores que não comprometerão seu orçamento.
2. **Diversifique**: Não coloque todo seu dinheiro em uma única empresa ou setor.
3. **Estude antes de investir**: Conheça os fundamentos da empresa e do setor.
4. **Tenha paciência**: Investimento em ações é uma estratégia de longo prazo.
5. **Reinvista os dividendos**: Para aproveitar o poder dos juros compostos.

## Conclusão

Investir em ações pode ser uma excelente forma de construir patrimônio no longo prazo, mas requer estudo, disciplina e paciência. É importante entender que o mercado de ações apresenta volatilidade no curto prazo, mas tende a gerar retornos positivos para investidores que mantêm uma estratégia consistente ao longo do tempo."""
        },
        {
            "filename": "investimentos_renda_fixa.txt",
            "title": "Guia de Renda Fixa",
            "author": "Equipe IA Treinável",
            "category": "renda fixa",
            "content": """# Investimentos em Renda Fixa: Guia Completo

## O que é Renda Fixa?

Renda fixa é uma categoria de investimentos na qual o investidor empresta dinheiro a uma instituição (governo, banco ou empresa) e recebe em troca uma remuneração que pode ser previamente definida ou seguir um indexador. A principal característica da renda fixa é a previsibilidade dos retornos, em contraste com a renda variável.

## Principais Tipos de Investimentos em Renda Fixa

### Tesouro Direto
São títulos públicos emitidos pelo Governo Federal para financiar a dívida pública. Existem três categorias principais:

1. **Tesouro Prefixado**: Rentabilidade definida no momento da compra.
2. **Tesouro SELIC**: Rentabilidade atrelada à taxa SELIC.
3. **Tesouro IPCA+**: Rentabilidade atrelada à inflação (IPCA) mais uma taxa prefixada.

### CDB (Certificado de Depósito Bancário)
É um título emitido por bancos para captar recursos. O investidor empresta dinheiro ao banco e recebe juros por isso. A rentabilidade pode ser prefixada ou pós-fixada (geralmente atrelada ao CDI).

### LCI (Letra de Crédito Imobiliário) e LCA (Letra de Crédito do Agronegócio)
São títulos emitidos por instituições financeiras para financiar o setor imobiliário (LCI) ou o agronegócio (LCA). Oferecem isenção de Imposto de Renda para pessoas físicas e geralmente têm rentabilidade atrelada ao CDI.

### Debêntures
São títulos de dívida emitidos por empresas para captar recursos. O investidor empresta dinheiro à empresa e recebe juros periodicamente. Algumas debêntures (chamadas de "incentivadas") oferecem isenção de Imposto de Renda.

## Vantagens da Renda Fixa

1. **Previsibilidade**: Retornos mais previsíveis em comparação com a renda variável.
2. **Segurança**: Geralmente apresenta menor volatilidade e risco.
3. **Diversidade**: Ampla variedade de produtos com diferentes perfis de risco e retorno.
4. **Liquidez**: Muitos produtos oferecem boa liquidez, permitindo resgate antes do vencimento.

## Riscos da Renda Fixa

1. **Risco de Crédito**: Possibilidade de o emissor não honrar o pagamento.
2. **Risco de Mercado**: Variações nas taxas de juros podem afetar o valor do título.
3. **Risco de Liquidez**: Dificuldade em vender o título antes do vencimento sem perda de valor.
4. **Risco de Inflação**: Retornos podem ser corroídos pela inflação, especialmente em títulos prefixados.

## Como Escolher Investimentos em Renda Fixa

1. **Defina seus objetivos**: Curto, médio ou longo prazo.
2. **Avalie seu perfil de risco**: Conservador, moderado ou arrojado.
3. **Compare a rentabilidade**: Verifique a taxa oferecida em relação a outros investimentos.
4. **Verifique a liquidez**: Considere quando precisará do dinheiro.
5. **Observe os custos**: Taxas de administração, custódia e impostos.
6. **Diversifique**: Não concentre todos os recursos em um único título ou emissor.

## Tributação na Renda Fixa

A maioria dos investimentos em renda fixa está sujeita à cobrança de Imposto de Renda, com alíquotas regressivas conforme o prazo:
- Até 180 dias: 22,5%
- De 181 a 360 dias: 20%
- De 361 a 720 dias: 17,5%
- Acima de 720 dias: 15%

Exceções incluem LCI, LCA e algumas debêntures incentivadas, que são isentas de IR para pessoas físicas.

## Conclusão

Investimentos em renda fixa são excelentes opções para diversificar a carteira, proteger o patrimônio e obter retornos previsíveis. São especialmente indicados para objetivos de curto e médio prazo, ou para a parcela mais conservadora de uma carteira de investimentos. A chave para o sucesso está em escolher os produtos adequados ao seu perfil e objetivos, sempre considerando fatores como prazo, rentabilidade, risco e tributação."""
        },
        {
            "filename": "fundos_imobiliarios.txt",
            "title": "Fundos Imobiliários: Investimento em Imóveis sem Dor de Cabeça",
            "author": "Equipe IA Treinável",
            "category": "fundos imobiliários",
            "content": """# Fundos Imobiliários: Investimento em Imóveis sem Dor de Cabeça

## O que são Fundos Imobiliários (FIIs)?

Fundos Imobiliários (FIIs) são instrumentos de investimento que permitem aplicar em empreendimentos imobiliários sem a necessidade de comprar diretamente um imóvel. Funcionam como um condomínio de investidores, onde o dinheiro captado é utilizado para adquirir ou construir imóveis, que posteriormente geram renda através de aluguéis ou valorização.

## Como Funcionam os FIIs

Os FIIs são divididos em cotas, que representam uma fração do patrimônio do fundo. Ao comprar cotas, o investidor se torna proprietário de uma parcela de todos os imóveis do fundo e tem direito a receber proporcionalmente os rendimentos gerados.

A gestão dos imóveis é realizada por uma administradora profissional, que cuida de todos os aspectos operacionais: manutenção, busca por inquilinos, cobrança de aluguéis, etc. Isso elimina as dores de cabeça típicas de quem possui imóveis físicos.

## Tipos de Fundos Imobiliários

### Fundos de Tijolo
Investem diretamente em imóveis físicos, como escritórios, galpões logísticos, shopping centers ou hospitais. A renda vem principalmente dos aluguéis pagos pelos inquilinos.

### Fundos de Papel
Investem em títulos relacionados ao mercado imobiliário, como Certificados de Recebíveis Imobiliários (CRIs), Letras de Crédito Imobiliário (LCIs) e outros. A renda vem dos juros desses papéis.

### Fundos Híbridos
Combinam investimentos em imóveis físicos e papéis, buscando diversificação e equilíbrio entre segurança e rentabilidade.

### Fundos de Fundos (FOFs)
Investem em cotas de outros fundos imobiliários, oferecendo maior diversificação com um único investimento.

## Vantagens dos Fundos Imobiliários

1. **Acessibilidade**: É possível começar com valores relativamente baixos, a partir de algumas centenas de reais.
2. **Renda Mensal**: A maioria dos FIIs distribui rendimentos mensalmente.
3. **Isenção Fiscal**: Pessoas físicas são isentas de Imposto de Renda sobre os rendimentos distribuídos (mas não sobre ganho de capital na venda).
4. **Liquidez**: As cotas são negociadas na bolsa de valores, permitindo compra e venda com facilidade.
5. **Diversificação**: Com o mesmo capital necessário para comprar um imóvel, é possível investir em diversos fundos com diferentes características.
6. **Gestão Profissional**: Não é preciso se preocupar com a administração dos imóveis.

## Riscos dos Fundos Imobiliários

1. **Vacância**: Imóveis podem ficar sem inquilinos, reduzindo os rendimentos.
2. **Inadimplência**: Inquilinos podem atrasar ou deixar de pagar aluguéis.
3. **Desvalorização**: O valor dos imóveis e, consequentemente, das cotas pode cair.
4. **Risco de Mercado**: Fatores macroeconômicos, como alta de juros, podem impactar negativamente o setor.
5. **Risco de Crédito**: Em fundos de papel, existe o risco de não pagamento dos títulos.
6. **Liquidez Reduzida**: Alguns fundos têm baixo volume de negociação, dificultando a compra ou venda.

## Como Escolher Fundos Imobiliários

1. **Analise o Patrimônio**: Verifique quais imóveis ou títulos compõem o fundo.
2. **Avalie a Qualidade dos Inquilinos**: Inquilinos sólidos reduzem riscos de inadimplência.
3. **Observe a Taxa de Vacância**: Quanto menor, melhor.
4. **Verifique o Dividend Yield**: Rendimento anual em relação ao preço da cota.
5. **Analise a Liquidez**: Fundos mais líquidos facilitam entradas e saídas.
6. **Conheça a Gestora**: Gestoras experientes tendem a entregar melhores resultados.
7. **Diversifique**: Invista em diferentes tipos de fundos e segmentos imobiliários.

## Tributação dos FIIs

- **Rendimentos**: Isentos de Imposto de Renda para pessoas físicas.
- **Ganho de Capital**: Venda de cotas com lucro é tributada em 20% (alíquota fixa).
- **Declaração**: É necessário declarar as cotas e rendimentos no Imposto de Renda.

## Conclusão

Os Fundos Imobiliários representam uma excelente alternativa para investir no mercado imobiliário de forma mais acessível, líquida e diversificada. Permitem que investidores de diferentes perfis e capacidades financeiras participem deste mercado tradicionalmente restrito a grandes capitais.

Como todo investimento, exigem estudo e análise cuidadosa antes da aplicação. A diversificação entre diferentes fundos e a compreensão das características específicas de cada um são fundamentais para construir uma carteira equilibrada e alinhada aos seus objetivos financeiros."""
        },
        {
            "filename": "investimentos_internacionais.txt",
            "title": "Investimentos Internacionais: Diversificação Global",
            "author": "Equipe IA Treinável",
            "category": "investimentos internacionais",
            "content": """# Investimentos Internacionais: Diversificação Global

## Por que Investir Internacionalmente?

Investir internacionalmente permite diversificar sua carteira além das fronteiras do seu país, reduzindo a exposição a riscos locais e aproveitando oportunidades em economias com diferentes ciclos de crescimento. A diversificação global é uma estratégia poderosa para proteger e potencializar seu patrimônio no longo prazo.

## Principais Formas de Investir no Exterior

### 1. ETFs (Exchange Traded Funds) Internacionais
São fundos negociados em bolsa que replicam índices de mercados internacionais. Permitem exposição a mercados globais com baixo custo e alta liquidez.

**Exemplos:**
- ETFs que replicam o S&P 500 (mercado americano)
- ETFs de mercados emergentes
- ETFs setoriais globais (tecnologia, saúde, energia)

### 2. BDRs (Brazilian Depositary Receipts)
São certificados que representam ações de empresas estrangeiras negociados na bolsa brasileira. Permitem investir em grandes empresas globais usando reais.

**Vantagens:**
- Negociação em reais
- Não é necessário abrir conta no exterior
- Processo simplificado de declaração de IR

### 3. Conta em Corretora Internacional
Abrir conta em uma corretora no exterior permite acesso direto aos mercados internacionais, com maior variedade de ativos.

**Possibilidades:**
- Ações de empresas globais
- ETFs internacionais
- REITs (equivalentes aos FIIs)
- Bonds (títulos de dívida)

### 4. Fundos de Investimento Internacionais
Fundos geridos por profissionais que investem em ativos internacionais. Podem ser acessados através de plataformas de investimento brasileiras.

**Tipos:**
- Fundos de ações internacionais
- Fundos multimercado com exposição global
- Fundos cambiais

## Vantagens dos Investimentos Internacionais

1. **Diversificação de Risco**: Reduz a exposição a crises econômicas locais.
2. **Acesso a Setores Inovadores**: Possibilidade de investir em setores pouco desenvolvidos no Brasil.
3. **Proteção Cambial**: Exposição a outras moedas pode proteger contra desvalorização da moeda local.
4. **Oportunidades em Mercados Desenvolvidos**: Acesso a economias mais estáveis e maduras.
5. **Oportunidades em Mercados Emergentes**: Potencial de crescimento acelerado em economias em desenvolvimento.

## Riscos dos Investimentos Internacionais

1. **Risco Cambial**: Flutuações na taxa de câmbio podem impactar os retornos.
2. **Risco Geopolítico**: Instabilidades políticas em outros países podem afetar investimentos.
3. **Risco Regulatório**: Diferentes regras e regulamentações em cada país.
4. **Custos Adicionais**: Taxas de câmbio, remessas internacionais e custos operacionais.
5. **Complexidade Tributária**: Declaração de investimentos internacionais no Imposto de Renda.

## Tributação de Investimentos Internacionais

### Investimentos via Brasil (BDRs e Fundos)
- Seguem regras similares aos investimentos em renda variável no Brasil
- Alíquota de 15% sobre ganho de capital
- Isenção para vendas mensais até R$ 20.000 (no caso de BDRs)

### Investimentos Diretos no Exterior
- Ganhos são tributados apenas no momento da realização (venda)
- Alíquota de 15% a 22,5% sobre o ganho de capital, dependendo do valor
- Rendimentos (dividendos, juros) são tributados no momento do recebimento
- Necessidade de declaração anual de bens e direitos no exterior (CBE) se o valor for superior a US$ 100.000

## Estratégias para Investimentos Internacionais

### Para Iniciantes
1. **Comece com BDRs ou ETFs**: São opções mais simples e acessíveis.
2. **Diversifique Gradualmente**: Comece com uma pequena porcentagem da carteira.
3. **Foque em Mercados Desenvolvidos**: Inicialmente, priorize mercados mais estáveis.

### Para Investidores Experientes
1. **Diversificação Geográfica**: Distribua investimentos entre diferentes regiões e países.
2. **Diversificação por Classe de Ativos**: Combine ações, renda fixa e imóveis internacionais.
3. **Estratégia de Rebalanceamento**: Ajuste periodicamente a alocação conforme os objetivos.

## Dicas Práticas

1. **Estude o Mercado**: Compreenda as particularidades de cada mercado antes de investir.
2. **Atenção ao Câmbio**: Considere o momento de entrada em relação à taxa de câmbio.
3. **Planejamento Tributário**: Organize-se para a declaração correta no Imposto de Renda.
4. **Investimento Regular**: Utilize a estratégia de custo médio para reduzir o impacto da volatilidade cambial.
5. **Horizonte de Longo Prazo**: Investimentos internacionais funcionam melhor com perspectiva de longo prazo.

## Conclusão

Investir internacionalmente é uma estratégia fundamental para diversificação e proteção patrimonial no longo prazo. Com as diversas opções disponíveis atualmente, desde as mais simples até as mais sofisticadas, é possível construir uma carteira global independentemente do seu perfil de investidor ou capital disponível. O importante é começar com estudo, planejamento e uma estratégia consistente com seus objetivos financeiros."""
        }
    ]
    
    created_files = []
    
    for sample in samples:
        output_path = os.path.join(output_dir, sample["filename"])
        
        # Verificar se o arquivo já existe
        if os.path.exists(output_path):
            logger.info(f"Arquivo já existe: {output_path}")
        else:
            # Criar arquivo
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(sample["content"])
            logger.info(f"Arquivo criado: {output_path}")
        
        created_files.append({
            "path": output_path,
            "metadata": {
                "title": sample.get("title", ""),
                "author": sample.get("author", ""),
                "category": sample.get("category", "")
            }
        })
    
    return created_files

def test_import_and_train(ai, files):
    """
    Testa a importação de arquivos e treinamento do modelo.
    
    Args:
        ai: Instância da IA treinável
        files: Lista de arquivos a serem importados
    
    Returns:
        Resultado do treinamento
    """
    logger.info("Iniciando teste de importação e treinamento...")
    
    # Importar arquivos
    imported_docs = []
    
    for file_info in files:
        file_path = file_info["path"]
        metadata = file_info["metadata"]
        
        logger.info(f"Importando arquivo: {file_path}")
        result = ai.import_and_process_file(file_path, metadata)
        
        if result['status'] == 'success':
            logger.info(f"Arquivo importado com sucesso. ID do documento: {result['doc_id']}")
            imported_docs.append(result['doc_id'])
        else:
            logger.error(f"Erro ao importar arquivo: {result.get('message', 'Erro desconhecido')}")
    
    if not imported_docs:
        logger.error("Nenhum documento importado com sucesso. Abortando treinamento.")
        return None
    
    # Treinar modelo
    logger.info(f"Treinando modelo com {len(imported_docs)} documentos...")
    result = ai.train_model(imported_docs)
    
    # Verificar resultado do treinamento
    embedding_result = result.get('embedding_training', {})
    if embedding_result.get('status') == 'success':
        logger.info(f"Treinamento de embeddings concluído com sucesso.")
        logger.info(f"Índice criado: {embedding_result.get('index_name')}")
        logger.info(f"Documentos processados: {embedding_result.get('document_count')}")
    else:
        logger.error(f"Erro no treinamento de embeddings: {embedding_result.get('message', 'Erro desconhecido')}")
    
    return result

def test_questions(ai):
    """
    Testa o modelo com perguntas sobre investimentos.
    
    Args:
        ai: Instância da IA treinável
    
    Returns:
        Resultados das perguntas
    """
    logger.info("Testando modelo com perguntas sobre investimentos...")
    
    # Lista de perguntas para teste
    questions = [
        "Quais são as principais estratégias de investimento em ações?",
        "Como funcionam os fundos imobiliários e quais suas vantagens?",
        "Qual a diferença entre investimentos em renda fixa e renda variável?",
        "Quais são as vantagens de investir internacionalmente?",
        "O que é a estratégia Buy and Hold e como aplicá-la?"
    ]
    
    results = []
    
    for question in questions:
        logger.info(f"Pergunta: {question}")
        
        try:
            # Fazer pergunta
            response_data = ai.answer_question(question)
            
            # Registrar resultado
            results.append({
                "question": question,
                "response": response_data['response'],
                "sources_count": len(response_data.get('sources', []))
            })
            
            logger.info(f"Resposta gerada com {len(response_data.get('sources', []))} fontes")
        except Exception as e:
            logger.error(f"Erro ao processar pergunta: {e}")
            results.append({
                "question": question,
                "error": str(e)
            })
    
    return results

def main():
    """Função principal para testar a IA treinável."""
    parser = argparse.ArgumentParser(description='Testar IA Treinável com dados de investimento')
    parser.add_argument('--data-dir', type=str, default='./test_data', help='Diretório para dados de teste')
    parser.add_argument('--skip-download', action='store_true', help='Pular download de dados de amostra')
    parser.add_argument('--skip-import', action='store_true', help='Pular importação e treinamento')
    parser.add_argument('--output', type=str, default='./test_results.json', help='Arquivo para salvar resultados')
    
    args = parser.parse_args()
    
    # Criar diretório de dados se não existir
    os.makedirs(args.data_dir, exist_ok=True)
    
    # Inicializar pipeline e IA
    pipeline = create_pipeline()
    ai = create_trainable_ai(pipeline)
    
    files = []
    
    # Baixar ou criar dados de amostra
    if not args.skip_download:
        # Tentar baixar dados reais
        downloaded_files = download_sample_data(args.data_dir)
        files.extend(downloaded_files)
        
        # Criar arquivos de texto de amostra
        created_files = create_sample_text_files(args.data_dir)
        files.extend(created_files)
    
    # Importar e treinar
    if not args.skip_import and files:
        training_result = test_import_and_train(ai, files)
    else:
        logger.info("Pulando importação e treinamento...")
    
    # Testar com perguntas
    question_results = test_questions(ai)
    
    # Salvar resultados
    results = {
        "files_processed": len(files),
        "questions_tested": len(question_results),
        "question_results": question_results,
        "model_info": ai.get_model_info()
    }
    
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    
    logger.info(f"Resultados salvos em {args.output}")
    
    # Mostrar resumo
    print("\n===== RESUMO DO TESTE =====")
    print(f"Arquivos processados: {len(files)}")
    print(f"Perguntas testadas: {len(question_results)}")
    print("\nExemplos de perguntas e respostas:")
    
    for i, result in enumerate(question_results[:3]):  # Mostrar apenas as 3 primeiras
        print(f"\nPergunta {i+1}: {result['question']}")
        if 'response' in result:
            # Limitar tamanho da resposta para exibição
            response = result['response']
            if len(response) > 300:
                response = response[:300] + "..."
            print(f"Resposta: {response}")
        else:
            print(f"Erro: {result.get('error', 'Desconhecido')}")
    
    print(f"\nResultados completos salvos em {args.output}")

if __name__ == "__main__":
    main()
